import UIKit
//: # Point Calculation Demos
var image : UIImage!
let sideLength : CGFloat = 250.0
let inset : CGFloat = sideLength / 5.0
let random = {RandomPosition(UInt32(sideLength))}

// Create a random line segment and point
var p1 = CGPointMake(random(), random())
var p2 = CGPointMake(random(), random())
var p = CGPointMake(random(), random())
var segment = Segment(p1: p1, p2:p2)

image = DrawImage(CGSizeMake(sideLength + inset * 2.0, sideLength + inset * 2.0)) {
    CGContextTranslateCTM(UIGraphicsGetCurrentContext(), inset, inset)
    
    // Draw the segment and its midpoint
    let midpoint = segment.midpoint
    UIBezierPath(dottedSegment: segment).stroke()
    UIBezierPath(point:midpoint, radius:6).fill(.orangeColor())
    UIBezierPath(point: p, radius: 6).fill(.blueColor())
    
    // Highlight the perpendicular
    let perpPoint = p.projectedOntoPerpendicular(segment)
    let perpSegment = Segment(p1:midpoint, p2: perpPoint)
    let perpPath = UIBezierPath(dottedSegment: perpSegment)
    perpPath.strokeWithColor(.orangeColor()); perpPath.fill(.orangeColor())
    
    // Find the projection of the point on the line
    let projection = p.projectedToLine(segment)
    let projectionSegment = Segment(p1:p, p2:projection)
    let projPath = UIBezierPath(dottedSegment: projectionSegment)
    projPath.stroke(); projPath.fill(.blueColor())
    
    // Add circle backsplash
    UIBezierPath(point: projection, radius: p.distanceToLine(segment)).fill(UIColor.grayColor().colorWithAlphaComponent(0.4))
    UIBezierPath(projection, p).stroke()
    
    // Find reflection of point across line
    let reflection = p.mirroredAcrossLine(segment)
    UIBezierPath(point: reflection, radius: 6).fill(UIColor.blueColor().colorWithAlphaComponent(0.5))
    
    // Find mirror point reflected across perpendicular
    let mirror = p.mirroredAcrossPerpendicular(segment)
    UIBezierPath(point: mirror, radius: 6).fill(.purpleColor())
    UIBezierPath(p, mirror).strokeWithColor(.purpleColor())
}
image

//: Re-execute this playground with new random segments by choosing Editor > Execute Playground
