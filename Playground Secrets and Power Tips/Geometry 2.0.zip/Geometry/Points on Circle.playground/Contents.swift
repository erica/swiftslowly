import UIKit
//: # Points on Circle Demo
var image : UIImage!
let sideLength : CGFloat = 250.0
let random = {RandomPosition(UInt32(sideLength))}

let point1 = CGPointMake(random(), random())
let point2 = CGPointMake(random(), random())
let segment = Segment(p1:point1, p2:point2)
let radius : CGFloat = 70.0

//: For any two points and a given radius, attempt to find the center point for a circle that passes through those points.
image = DrawImage(CGSizeMake(250, 250)){
    UIBezierPath(point1).fill()
    UIBezierPath(point2).fill()
    if let center = segment.centerWithRadius(radius, clockwise: true) {
        UIBezierPath(center).fill(.greenColor())
        UIBezierPath(point:center, radius:radius).stroke()
    }
}
image


//: Re-execute this playground with new random segments by choosing Editor > Execute Playground
