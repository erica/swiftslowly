import AppKit
import XCPlayground
import Carbon

XCPSetExecutionShouldContinueIndefinitely(continueIndefinitely: true)

// A simple delegate that can do things when asked nicely
class Delegate : NSObject {
    func test(sender: AnyObject?) {
        println("Test")
    }
}
var delegate = Delegate()

// Load the xib
var itemArray = NSArray()
var outputValue = AutoreleasingUnsafeMutablePointer<NSArray?>(&itemArray)
NSBundle.mainBundle().loadNibNamed("MainMenu", owner: nil, topLevelObjects: outputValue)

// Find items within the xib
var window : NSWindow
for item in itemArray {
    if item is NSWindow {
        window = (item as? NSWindow)!
        
        // Make the window prominent but out of the way
        window.level = 7
        window.setFrameOrigin(CGPointMake(1300, 700))
        
        // Create a button with an action
        if let button = window.contentView.viewWithTag(11) as? NSButton {
            button.action = "test:"; button.target = delegate;
        }
        
        // Create the Main Window (⌘-1) menu item functionality
        let fileMenuItem = NSApp.mainMenu?!.itemWithTag(12)
        let fileMenu = fileMenuItem?.submenu
        let menuItem = fileMenu?.itemWithTag(13)
        if let menuItem = menuItem {
            menuItem.target = window; menuItem.action = "makeKeyAndOrderFront:"
        }
    }
}

// Thanks Mike Ash
NSApplication.sharedApplication().setActivationPolicy(.Regular)
