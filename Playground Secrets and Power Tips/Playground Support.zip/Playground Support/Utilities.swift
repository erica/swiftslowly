import Foundation

public let Lipsum = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ante diam, faucibus sed sem eu, euismod finibus turpis. Nunc risus odio, tincidunt sit amet eleifend a, semper ullamcorper nunc. Duis ligula dui, interdum nec magna id, varius commodo metus.\n\nNunc pharetra justo et enim scelerisque molestie. Etiam sagittis aliquam sollicitudin. Aliquam mattis mattis orci, in placerat orci tempor sed. Duis et pretium ipsum. Cras fringilla tincidunt metus, ut dapibus augue ultricies non. Proin mattis, dolor id accumsan porttitor, ex erat suscipit arcu, vitae aliquam dolor erat in nunc.\n\nDonec vitae finibus velit, pharetra sodales sem. Curabitur ultrices bibendum purus, a sollicitudin massa. Proin auctor auctor erat, tempor mollis velit ultricies id. Duis euismod quam vel sagittis congue. Aliquam nunc orci, tempor a condimentum vel, rhoncus id ex.\n\nMaecenas non eros sit amet lorem interdum porta varius in risus."

public func TestTime(block : ()->()) {
    let date = NSDate()
    block()
    let timeInterval = NSDate().timeIntervalSinceDate(date)
    println("Elapsed time: \(timeInterval)")
}

let DocumentsPath = NSHomeDirectory().stringByAppendingPathComponent("Documents/Shared Playground Data")

