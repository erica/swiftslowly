import UIKit

public let SimulatorSupportDefined = true

public class ViewController : UIViewController {
    public func quitApp() {CFRunLoopStop(CFRunLoopGetCurrent())}
    public func barButton(title : String, action : String) -> UIBarButtonItem {
        return UIBarButtonItem(title: title, style: .Plain, target: self, action: Selector(action))
    }
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .whiteColor()
        extendedLayoutIncludesOpaqueBars = false
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Quit", style: .Plain, target: self, action: "quitApp")
    }
}

public var window = UIWindow(frame: UIScreen.mainScreen().bounds)

public func RunApp(viewController: ViewController) {
    let nav = UINavigationController(rootViewController: viewController)
    window.rootViewController = nav
    window.makeKeyAndVisible()
    CFRunLoopRun()
}