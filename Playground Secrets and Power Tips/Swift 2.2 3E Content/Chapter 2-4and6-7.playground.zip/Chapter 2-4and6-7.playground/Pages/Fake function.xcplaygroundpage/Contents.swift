import UIKit

func myFunction() -> NotReal {
    
}

"Hello World" // no sidebar results
