#if os(iOS)
print("iOS")
#elseif os(tvos)
print("tvOS")
#elseif os(osx)
print("OSX")
#endif


