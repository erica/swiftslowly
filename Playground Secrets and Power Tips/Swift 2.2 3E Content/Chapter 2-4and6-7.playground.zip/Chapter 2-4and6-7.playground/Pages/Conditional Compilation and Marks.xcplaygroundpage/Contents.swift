#if os(iOS)
print("iOS")
#elseif os(tvOS)
print("tvOS")
#elseif os(OSX)
print("OSX")
#endif


