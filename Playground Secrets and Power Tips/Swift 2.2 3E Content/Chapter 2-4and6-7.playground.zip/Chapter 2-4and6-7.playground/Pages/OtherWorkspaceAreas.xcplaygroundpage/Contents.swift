//: [Previous](@previous)
import UIKit
import XCPlayground

guard let image = UIImage(named: "BlueCircles") else {
    fatalError("image not found")
}
let imageView = UIImageView(image: image)
XCPlaygroundPage.currentPage.liveView = imageView

//: [Next](@next)
