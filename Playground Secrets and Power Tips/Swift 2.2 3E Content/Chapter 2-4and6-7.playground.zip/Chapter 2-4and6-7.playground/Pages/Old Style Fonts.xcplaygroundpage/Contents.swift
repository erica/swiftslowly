import UIKit
import CoreText

func loadFont(name: String) -> Bool {
    guard let path = NSBundle.mainBundle()
        .pathForResource(name, ofType: "ttf") else { return false }
    let url = NSURL(fileURLWithPath: path)
    let dataProvider = CGDataProviderCreateWithURL(url)
    guard let newFont = CGFontCreateWithDataProvider(dataProvider) else { return false }
    let newFontName = CGFontCopyPostScriptName(newFont)
    let success = CTFontManagerRegisterGraphicsFont(newFont, nil)
    print(success ? "Loaded \(newFontName!)" :
        "Unable to load font \(name)")
    return success
}

if
    loadFont("Ubuntu-B"),
    let font = UIFont(name: "Ubuntu", size: 32.0)
{
    let attributedString = NSAttributedString(
        string: "Hello World",
        attributes: [NSFontAttributeName: font]
    )
}
