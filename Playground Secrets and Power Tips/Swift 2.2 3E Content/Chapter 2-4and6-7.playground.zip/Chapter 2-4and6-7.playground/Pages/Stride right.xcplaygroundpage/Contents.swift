
// This will change in Swift 3. Be warned
let sequence = Array(0.0.stride(through: 4.0, by: 0.25))
for value in sequence {
    value // linear
    value * value // square
    value * value * value // cube
}

import UIKit
let colors = 0.0.stride(through: 1.0, by: 0.1).map {
    UIColor(red: CGFloat($0), green:0.5, blue:1.0, alpha: 2.0)
}
