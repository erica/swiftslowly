import UIKit
import XCPlayground

// Create thumb
UIGraphicsBeginImageContext(CGSizeMake(48, 48))
let path = UIBezierPath()
path.appendPath(UIBezierPath(roundedRect: CGRectMake(4, 4, 40, 40), cornerRadius: 8))
path.appendPath(UIBezierPath(ovalInRect: CGRectMake(20, 20, 8, 8)))
path.lineWidth = 4
UIColor.redColor().set()
path.stroke()
let thumb = UIGraphicsGetImageFromCurrentImageContext()
UIGraphicsEndImageContext()

let SliderKey = "SliderKey"

// Build and tweak slider
let slider = UISlider(frame: CGRectMake(0, 0, 200, 40))
slider.value = 0.5
slider.minimumTrackTintColor = UIColor.greenColor()
slider.maximumTrackTintColor = UIColor.orangeColor()
slider.setThumbImage(thumb, forState: .Normal)

import XCPlayground
slider.backgroundColor = .whiteColor()
XCPlaygroundPage.currentPage.liveView = slider
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
