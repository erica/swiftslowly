import UIKit
import XCPlayground

var array: [Int] = []
for index in 1...10 {
    let value = Int(arc4random_uniform(20)); array.append(value)
    XCPlaygroundPage.currentPage.captureValue(value, withIdentifier: "Input")
}

array.sortInPlace()
for value in array {
    XCPlaygroundPage.currentPage.captureValue(value, withIdentifier: "Output")
}

