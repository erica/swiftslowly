//: Playground - noun: a place where people can play

import UIKit
import XCPlayground

for value in 0.0.stride(through: 4.0, by: 0.25) {
    XCPlaygroundPage.currentPage.captureValue(value, withIdentifier: "Linear")
    XCPlaygroundPage.currentPage.captureValue(value * value * value, withIdentifier: "Cubic")
}