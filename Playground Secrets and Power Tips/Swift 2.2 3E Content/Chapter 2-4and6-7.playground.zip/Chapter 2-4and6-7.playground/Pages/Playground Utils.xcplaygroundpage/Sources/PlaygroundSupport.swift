/*

ericasadun.com
Playground Support: Add to playground's Sources folder

*/

import Foundation
import XCPlayground

// Convenience
public let fileManager = NSFileManager.defaultManager()

//------------------------------------------------------------------------------
// MARK: Process Info
// Return information about the playground process and the environment
// it is running within
//------------------------------------------------------------------------------

/// Access the playground's process info
public let processInfo = NSProcessInfo.processInfo()

/// The playground's environmental variables
public let processEnvironment = processInfo.environment

/// Keys in the environment dictionary for quick reference
public let environmentKeys = Array(processInfo.environment.keys)

/// Playground name (Used later to create a private documents folder)
public let playgroundName: String = NSProcessInfo.processInfo().processName as String

// Path to the playground's sandbox container
#if os(OSX)
    public let playgroundContainerPath: String = NSHomeDirectory()
        .ns.stringByDeletingLastPathComponent
#else
    // iOS, tvOS, watchOS
    public let playgroundContainerPath: String = (processEnvironment["PLAYGROUND_SANDBOX_CONTAINER_PATH"] ?? "?") as String
#endif

//------------------------------------------------------------------------------
// MARK: Application
// Return information about the pseudo-app that the playground builds/executes
// Note: I'd like a real-world path to Resources (path-to-playground/Resources)
// but I don't think that's going to happen with sandboxing enabled
//------------------------------------------------------------------------------

/// Path to the playground's bundle and resources
/// At this time, they are identical on iOS (but not OS X)
public let bundlePath = NSBundle.mainBundle().bundlePath
public let resourcePath = NSBundle.mainBundle().resourcePath ?? bundlePath

/// Bundle and Resource contents if available
public let bundleContents = try! fileManager.contentsOfDirectoryAtPath(bundlePath)
public let resourceContents = try! fileManager.contentsOfDirectoryAtPath(resourcePath)

/// Application Executable Path
public let executablePath: String! = NSBundle.mainBundle().executablePath

// NSString support
extension String { var ns: NSString { return self as NSString } }

/// Application .app Bundle Path
#if os(iOS)
    public let appPath = executablePath
        .ns.stringByDeletingLastPathComponent
#else
    public let appPath = executablePath
        .ns.stringByDeletingLastPathComponent
        .ns.stringByDeletingLastPathComponent
        .ns.stringByDeletingLastPathComponent
#endif

/// Playground Application Name
public let appName = (bundlePath as NSString).lastPathComponent

/// Access to the bundle's Info.plist dictionary
public let infoDictionary = NSBundle.mainBundle().infoDictionary

//------------------------------------------------------------------------------
// MARK: Shared Data Folder
// The shared playground data in the user Documents foler
//------------------------------------------------------------------------------

/// The document path INSIDE THE SANDBOX
public let documentPath = NSSearchPathForDirectoriesInDomains(
    .DocumentDirectory, .UserDomainMask, true)[0] as NSString
public let sharedDataPath = documentPath
    .stringByAppendingPathComponent("Shared Playground Data") as NSString

/// The Shared Playground Data folder OUTSIDE THE SANDBOX
public let sharedDataFolder = (processEnvironment["PLAYGROUND_SHARED_DATA_FOLDER"] ?? "~/Documents/Shared Playground Data") as String


//------------------------------------------------------------------------------
// MARK: Documents
// Return paths to the playground's documents folder by
// stepping down the path from NSHomeDirectory()
//------------------------------------------------------------------------------

#if !os(OSX)
    // The Shared Resources Folder for the simulator
    // Typically ~/Library/Application Support/iPhone Simulator
    public let sharedResourcesFolder = (processEnvironment["IPHONE_SHARED_RESOURCES_DIRECTORY"] ?? "?") as String
#endif

// The shared data from within the documents in the sandbox
public let homeFolder = NSHomeDirectory() as NSString
public let documentsFolder = homeFolder.stringByAppendingPathComponent("Documents") as NSString
public let playgroundDocumentFolder = documentsFolder.stringByAppendingPathComponent("Shared Playground Data")

//------------------------------------------------------------------------------
// MARK: Custom Subfolder
// A custom subfolder to store this playground's data
// (This is not a default behavior, but meant to keep the
// shared documents folder cleaner)
//------------------------------------------------------------------------------

/// From the shared data into a playground-named subfolder
public let sharedDocsFolder: String! = XCPlaygroundSharedDataDirectoryURL.path

/// Playground-named Documents folder
public let myDocumentsFolder = sharedDocsFolder
    .ns.stringByAppendingPathComponent(playgroundName)

/// Public-named Documents folder
let escapedPlaygroundName = playgroundName.ns.stringByReplacingOccurrencesOfString(" ", withString: "\\ ")
public let playgroundDocumentsFolder = "~/Documents/Shared\\ Playground\\ Data/" + escapedPlaygroundName

/// Playground-named Documents URL
public let myDocumentsURL = XCPlaygroundSharedDataDirectoryURL.URLByAppendingPathComponent(playgroundName)

/// Establish Playground-Named Documents Folder
public func establishMyDocumentsFolder() {
    do {
        try NSFileManager.defaultManager()
            .createDirectoryAtURL(myDocumentsURL,
                                  withIntermediateDirectories: true,
                                  attributes: [:])
    } catch {
        print("Unable to establish folder at", myDocumentsURL)
    }
}

/// Return contents of custom playground-named subfolder
/// The subfolder is created if it does not already exist
public func contentsOfMyDocumentsFolder() throws -> [AnyObject]? {
    if !fileManager.fileExistsAtPath(myDocumentsFolder) {establishMyDocumentsFolder()}
    return try fileManager.contentsOfDirectoryAtPath(myDocumentsFolder)
}
