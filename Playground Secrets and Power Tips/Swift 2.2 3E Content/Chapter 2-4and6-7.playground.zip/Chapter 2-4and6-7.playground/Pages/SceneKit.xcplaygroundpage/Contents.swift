import SceneKit

let scnscene = SCNScene()

// create and add a light to the scene
public let lightNode: SCNNode = {
    let theLight = SCNNode()
    theLight.light = SCNLight()
    theLight.light!.type = SCNLightTypeOmni
    theLight.position = SCNVector3(x: 0, y: 10, z: 10)
    scnscene.rootNode.addChildNode(theLight)
    return theLight
}()

// create and add a light to the scene
public let lightNode2: SCNNode = {
    $0.light = SCNLight()
    $0.light!.type = SCNLightTypeOmni
    $0.position = SCNVector3(x: 0, y: 10, z: 10)
    scnscene.rootNode.addChildNode($0)
    return $0
}(SCNNode())

