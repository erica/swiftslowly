import Foundation
import XCPlayground

// Establish indefinite execution
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

print("Starting")
dispatch_after(dispatch_time(DISPATCH_TIME_NOW,
    Int64(2.0 * Double(NSEC_PER_SEC))),
    dispatch_get_main_queue(),
    {
        print("Finished!")
        XCPlaygroundPage.currentPage.finishExecution()
    }
)

