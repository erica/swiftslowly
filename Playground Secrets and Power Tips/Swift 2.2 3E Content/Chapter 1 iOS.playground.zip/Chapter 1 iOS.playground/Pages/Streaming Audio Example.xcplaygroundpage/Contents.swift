import UIKit
import AVFoundation
import XCPlayground
/*
NBhosting: anyone able to show me an example how to play a live stream like http://108.61.73.120:8126/;stream/1
*/

XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
let streamrequest = "http://108.61.73.120:8126/;stream/1"
let url : NSURL! = NSURL(string:streamrequest)
let asset = AVAsset(URL: url)
let item = AVPlayerItem(asset: asset)
let player = AVPlayer(playerItem: item)
player.play()
