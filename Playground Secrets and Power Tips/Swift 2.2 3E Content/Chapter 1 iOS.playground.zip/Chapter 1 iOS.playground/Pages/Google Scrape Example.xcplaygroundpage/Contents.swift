import Foundation

var searchString = "Test Phrase"
searchString = ("client=firefox&q=" + searchString).stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!
var requestString = "http://suggestqueries.google.com/complete/search?" + searchString
var url = NSURL(string: requestString)!

let data = NSData(contentsOfURL: url)!
var json = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments) as! NSArray

for each in json[1] as! [String] {
    each
}
