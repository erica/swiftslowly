import UIKit

// For playing on
public let backdrop = UIView(frame:CGRectMake(0, 0, 640, 480))

// Make presentable
public func StylizedView(color : UIColor) -> UIView {
    let view = UIView()
    view.translatesAutoresizingMaskIntoConstraints = false
    view.layer.cornerRadius = 8
    view.layer.borderColor = UIColor.blackColor().CGColor
    view.layer.borderWidth = 2
    view.backgroundColor = color
    SizeView(view, size: CGSizeMake(80, 80), priority: 251)
    view.layoutIfNeeded()
    return view
}


public let redview = StylizedView(.redColor())
public let blueview = StylizedView(.blueColor())
public let greenview = StylizedView(.greenColor())
public let cyanview = StylizedView(.cyanColor())
public let yellowview = StylizedView(.yellowColor())
public let magentaview = StylizedView(.magentaColor())
public let purpleview = StylizedView(.purpleColor())
public let orangeview = StylizedView(.orangeColor())
public let brownview = StylizedView(.brownColor())