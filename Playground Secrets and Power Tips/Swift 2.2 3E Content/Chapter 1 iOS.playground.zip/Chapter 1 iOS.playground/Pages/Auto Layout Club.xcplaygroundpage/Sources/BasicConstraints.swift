/*
 
 Erica Sadun, http://ericasadun.com
 Auto Layout Demystified
 MINIPACK - iOS 8 and later
 // Note: Old and outdated for iOS 9
 
 */

import Foundation
import ObjectiveC
import UIKit

public typealias View = UIView

// Auto Layout
public typealias LayoutPriority = UILayoutPriority
public let SkipConstraint = CGRect.null.origin.x

// NSObject Nametag
public var sharedNametagKey: UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.alloc(1)
public extension NSObject {
    public var nametag: String? {
        get {return objc_getAssociatedObject(self, &sharedNametagKey) as? String}
        set {
            if let newNameTag = newValue {
                // Store unwrapped new value
                objc_setAssociatedObject(self, &sharedNametagKey, newNameTag, .OBJC_ASSOCIATION_RETAIN)
            } else {
                // Remove by assignment to nil
                objc_setAssociatedObject(self, &sharedNametagKey, nil, .OBJC_ASSOCIATION_RETAIN)
            }
        }
    }
}

// **************************************
// MARK: View Convenience
// **************************************

// Add views and prepare for auto layout
public extension View {
    public func addSubviews(views: View...) {
        views.forEach {
            addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
    }
}

public extension View {
    
    // Return superviews
    public var superviews: [View] {
        var array: [View] = []
        var currentView = self
        repeat {
            guard let view = currentView.superview else {break}
            array.append(view); currentView = view
        } while currentView.superview != nil
        return array
    }
    
    // Return nearest common ancestor between two views
    public func nearestCommonViewAncestorWith(otherView: View) -> View? {
        if self === otherView {return self}
        let mySuperviews = superviews
        let otherSuperviews = otherView.superviews
        
        // Check for superview relationships
        if mySuperviews.contains(otherView) {return otherView}
        if otherSuperviews.contains(self) {return self}
        
        // Check for indirect ancestor
        for eachItem in mySuperviews {
            if otherSuperviews.contains(eachItem) {return eachItem}
        }
        return nil
    }
}

// **************************************
// MARK: Constraint References
// **************************************

public extension NSLayoutConstraint {
    public var firstView: View {
        guard let theFirstView = firstItem as? View else {return View()}
        return theFirstView
    }
    public var secondView: View? {return secondItem as? View}
    public func refersToView(theView: View) -> Bool {
        if firstView == theView {return true}
        if let secondView = secondView {return secondView == theView}
        return false
    }
}

public extension View {
    public var externalConstraintReferences: [NSLayoutConstraint] {
        var constraints: [NSLayoutConstraint] = []
        for superview in superviews {
            for constraint in superview.constraints {
                if constraint.refersToView(self) {
                    constraints.append(constraint)
                }
            }
        }
        return constraints
    }
    
    public var internalConstraintReferences: [NSLayoutConstraint] {
        var constraints: [NSLayoutConstraint] = []
        for constraint in constraints {
            if constraint.refersToView(self) {
                constraints.append(constraint)
            }
        }
        return constraints
    }
}

// **************************************
// MARK: Enabling Auto Layout
// **************************************
public extension View {
    public var autoLayoutEnabled: Bool {
        get {return !translatesAutoresizingMaskIntoConstraints}
        set {translatesAutoresizingMaskIntoConstraints = !newValue}
    }
}


// **************************************
// MARK: Format Installation
// **************************************

public func InstallLayoutFormats(
    formats: [String],
    options: NSLayoutFormatOptions,
    metrics: [String:AnyObject]?,
    bindings: [String:AnyObject],
    priority: LayoutPriority) {
    let constraints = formats.flatMap ({
        NSLayoutConstraint.constraintsWithVisualFormat(
            $0,
            options: options,
            metrics: metrics,
            views: bindings)
    })
    constraints.forEach{$0.priority = priority}
    NSLayoutConstraint.activateConstraints(constraints)
}

// **************************************
// MARK: Sizing
// **************************************

// Constraining Sizes
public func SizeView(view: View, size: CGSize, priority: LayoutPriority) {
    let metrics = ["width":size.width, "height":size.height]
    let bindings = ["view":view]
    var formats: [String] = []
    if size.width != SkipConstraint { formats += ["H:[view(==width)]"] }
    if size.height != SkipConstraint { formats += ["V:[view(==height)]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainMinimumViewSize(view: View, size: CGSize, priority: LayoutPriority) {
    let metrics = ["width":size.width, "height":size.height]
    let bindings = ["view":view]
    var formats: [String] = []
    if size.width != SkipConstraint { formats += ["H:[view(>=width)]"] }
    if size.height != SkipConstraint { formats += ["V:[view(>=height)]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainMaximumViewSize(view: View, size: CGSize, priority: LayoutPriority) {
    let metrics = ["width":size.width, "height":size.height]
    let bindings = ["view":view]
    var formats: [String] = []
    if size.width != SkipConstraint { formats += ["H:[view(<=width)]"] }
    if size.height != SkipConstraint { formats += ["V:[view(<=height)]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

// **************************************
// MARK: Positioning
// **************************************

// Constraining Positions
public func PositionView(view: View, point: CGPoint, priority: LayoutPriority) {
    if view.superview == nil {return}
    let metrics = ["hLoc":point.x, "vLoc":point.y]
    let bindings = ["view":view]
    var formats: [String] = []
    if point.x != SkipConstraint { formats += ["H:|-hLoc-[view]"] }
    if point.y != SkipConstraint { formats += ["V:|-vLoc-[view]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainViewToSuperview(view: View, inset: Float, priority: LayoutPriority) {
    if view.superview == nil {return}
    let formats = [
        "H:|->=inset-[view]",
        "H:[view]->=inset-|",
        "V:|->=inset-[view]",
        "V:[view]->=inset-|"]
    InstallLayoutFormats(formats, options: [], metrics: ["inset":inset], bindings: ["view":view], priority: priority)
}

// **************************************
// MARK: Stretching
// **************************************

// Stretching to Superview
public func StretchViewHorizontallyToSuperview(view: View, inset: CGFloat, priority: LayoutPriority) {
    if view.superview == nil {return}
    let metrics = ["inset":inset]
    let bindings = ["view":view]
    let formats = ["H:|-inset-[view]-inset-|"]
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func StretchViewVerticallyToSuperview(view: View, inset: CGFloat, priority: LayoutPriority) {
    if view.superview == nil {return}
    let metrics = ["inset":inset]
    let bindings = ["view":view]
    let formats = ["V:|-inset-[view]-inset-|"]
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func StretchViewToSuperview(view: View, inset: CGSize, priority: LayoutPriority) {
    if view.superview == nil {return}
    if inset.width != SkipConstraint {
        StretchViewHorizontallyToSuperview(view, inset: inset.width, priority: priority)
    }
    if inset.height != SkipConstraint {
        StretchViewVerticallyToSuperview(view, inset: inset.height, priority: priority)
    }
}

// **************************************
// MARK: Alignment
// **************************************

// Aligning
public func AlignViewInSuperview(view: View, attribute: NSLayoutAttribute, inset: CGFloat, priority: LayoutPriority) {
    if view.superview == nil {return}
    var actualInset: CGFloat
    switch attribute {
    case .Left, .Leading, .Top:
        actualInset = -inset
    default:
        actualInset = inset
    }
    let superview = view.superview!
    let constraint = NSLayoutConstraint(item:superview, attribute:attribute, relatedBy: .Equal, toItem: view, attribute: attribute, multiplier: 1.0, constant: actualInset)
    constraint.priority = priority
    constraint.active = true
}

public func AlignViews(priority: LayoutPriority, view1: View, view2: View, attribute: NSLayoutAttribute) {
    let constraint: NSLayoutConstraint = NSLayoutConstraint(item: view1, attribute: attribute, relatedBy: .Equal, toItem: view2, attribute: attribute, multiplier: 1, constant: 0)
    constraint.priority = priority
    constraint.active = true
}

// View to View Layout
public func CenterViewInSuperview(view: View, horizontal: Bool, vertical: Bool, priority: LayoutPriority) {
    if view.superview == nil {return}
    if horizontal {AlignViews(priority, view1: view, view2: view.superview!, attribute: .CenterX)}
    if vertical {AlignViews(priority, view1: view, view2: view.superview!, attribute: .CenterY)}
}

/// Constrain several views at once. Views are named view1, view2, view3...
public func ConstrainViews(priority: LayoutPriority, format: String, metrics: [String:AnyObject], views: [View]) {
    
    // At least one view
    if views.isEmpty {return}
    
    // Install view names to bindings
    var bindings: [String:View] = [:]
    bindings["view"] = views.first
    for (index, view) in views.enumerate() {
        bindings["view\(index+1)"] = view
        view.translatesAutoresizingMaskIntoConstraints = false
    }
    
    // Generate and install constraints with priority
    InstallLayoutFormats([format], options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainViews(priority: LayoutPriority, format: String, views: View...) {
    ConstrainViews(priority, format: format, metrics: [String:AnyObject](), views: views)
}

public func ConstrainView(priority: LayoutPriority, format: String, metrics: [String:AnyObject], view: View) {
    ConstrainViews(priority, format: format, metrics: metrics, views: [view])
}

public func ConstrainView(priority: LayoutPriority, format: String, view: View) {
    ConstrainView(priority, format: format, metrics: [String:AnyObject](), view: view)
}

// **************************************
// MARK: iOS Layout Guides
// **************************************

// Working with Layout Guides. iOS Only
public func StretchViewToTopLayoutGuide(controller: UIViewController, view: View, inset: Int, priority: LayoutPriority) {
    let metrics = ["vinset":inset]
    let bindings = ["view":view, "topGuide":controller.topLayoutGuide as AnyObject]
    let formats = ["V:[topGuide]-vinset-[view]"]
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func StretchViewToBottomLayoutGuide(controller: UIViewController, view: View, inset: Int, priority: LayoutPriority) {
    let metrics = ["vinset":inset]
    let bindings = ["view":view, "bottomGuide":controller.bottomLayoutGuide as AnyObject]
    let formats = ["V:[view]-vinset-[bottomGuide]"]
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func StretchViewToController(controller: UIViewController, view: View, inset: CGSize, priority: LayoutPriority) {
    StretchViewToTopLayoutGuide(controller, view: view, inset: lrint(Double(inset.height)), priority: priority)
    StretchViewToBottomLayoutGuide(controller, view: view, inset: lrint(Double(inset.height)), priority: priority)
    StretchViewHorizontallyToSuperview(view, inset: inset.width, priority: priority)
}

// UIViewController extended layout
public extension UIViewController {
    public var useExtendedLayout: Bool {
        get {
            return !(edgesForExtendedLayout == .None)
        }
        set {
            edgesForExtendedLayout = newValue ? .All : .None
        }
    }
}

// **************************************
// MARK: Hug / Resist
// **************************************

public extension View {
    public var horizontalContentHuggingPriority: LayoutPriority {
        get {return contentHuggingPriorityForAxis(.Horizontal)}
        set {setContentHuggingPriority(newValue, forAxis: .Horizontal)}
    }
    public var verticalContentHuggingPriority: LayoutPriority {
        get {return contentHuggingPriorityForAxis(.Vertical)}
        set {setContentHuggingPriority(newValue, forAxis: .Vertical)}
    }
    public var contentHuggingPriority: LayoutPriority {
        get {
            // meaningless
            print("This priority is write-only")
            return 250
        }
        set {
            setContentHuggingPriority(newValue, forAxis: .Horizontal)
            setContentHuggingPriority(newValue, forAxis: .Vertical)
        }
    }
    public var horizontalContentCompressionResistancePriority: LayoutPriority {
        get {return contentCompressionResistancePriorityForAxis(.Horizontal)}
        set {setContentCompressionResistancePriority(newValue, forAxis: .Horizontal)}
    }
    public var verticalContentCompressionResistancePriority: LayoutPriority {
        get {return contentCompressionResistancePriorityForAxis(.Vertical)}
        set {setContentCompressionResistancePriority(newValue, forAxis: .Vertical)}
    }
    public var contentCompressionResistancePriority: LayoutPriority {
        get {
            // meaningless
            print("This priority is write-only")
            return 750
        }
        set {
            setContentCompressionResistancePriority(newValue, forAxis: .Horizontal)
            setContentCompressionResistancePriority(newValue, forAxis: .Vertical)
        }
    }
}

// --------------------------------------------------
// MARK: Placement utility
// --------------------------------------------------

public func PlaceViewInSuperview(view: View, position: String, inseth: CGFloat, insetv: CGFloat, priority: LayoutPriority) {
    if position.characters.count != 2 {return}
    if view.superview == nil {return}
    
    view.autoLayoutEnabled = true
    
    let verticalPosition = position.substringToIndex(position.startIndex.successor())
    let horizontalPosition = position.substringFromIndex(position.startIndex.successor())
    
    switch verticalPosition as String {
    case "t":
        AlignViewInSuperview(view, attribute: .Top, inset: insetv, priority: priority)
    case "c":
        AlignViewInSuperview(view, attribute: .CenterY, inset: insetv, priority: priority)
    case "b":
        AlignViewInSuperview(view, attribute: .Bottom, inset: insetv, priority: priority)
    case "x":
        StretchViewVerticallyToSuperview(view, inset: insetv, priority: priority)
    default: break
    }
    
    switch horizontalPosition as String {
    case "l":
        AlignViewInSuperview(view, attribute: .Leading, inset: inseth, priority: priority)
    case "c":
        AlignViewInSuperview(view, attribute: .CenterX, inset: inseth, priority: priority)
    case "r":
        AlignViewInSuperview(view, attribute: .Trailing, inset: inseth, priority: priority)
    case "x":
        StretchViewHorizontallyToSuperview(view, inset: inseth, priority: priority)
    default: break
    }
}

public func PlaceView(controller: UIViewController, view: View, position: String, inseth: CGFloat, insetv: CGFloat, priority: LayoutPriority) {
    view.autoLayoutEnabled = true
    if view.superview == nil {controller.view .addSubview(view)}
    
    if position.characters.count != 2 {return}
    var verticalPosition = position.substringToIndex(position.startIndex.successor())
    var horizontalPosition = position.substringFromIndex(position.startIndex.successor())
    
    // Handle the two stretching cases
    if position.hasPrefix("x") {
        StretchViewToTopLayoutGuide(controller, view: view, inset: lrint(Double(insetv)), priority: priority)
        StretchViewToBottomLayoutGuide(controller, view: view, inset: lrint(Double(insetv)), priority: priority)
        verticalPosition = "-"
    }
    
    if position.hasSuffix("x") {
        StretchViewHorizontallyToSuperview(view, inset: inseth, priority: priority)
        horizontalPosition = "-"
    }
    
    if position == "xx" {return}
    
    // Otherwise just place in superview
    PlaceViewInSuperview(view, position: (verticalPosition + horizontalPosition), inseth: inseth, insetv: insetv, priority: priority)
}