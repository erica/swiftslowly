import UIKit
backdrop.layer.borderWidth = 2

// Added but otherwise unconstrained other than default size
backdrop.addSubview(purpleview)
backdrop.addSubview(redview)
backdrop.addSubview(blueview)

// Put red in the middle
CenterViewInSuperview(redview, horizontal: true, vertical: true, priority: 500)

// Competing priorities
SizeView(redview, size: CGSizeMake(200, 90), priority: 700)
SizeView(redview, size: CGSizeMake(200, 50), priority: 701)

// AlignViews(500, blueview, redview, .CenterY)

AlignViews(500, view1: blueview, view2: redview, attribute: .CenterX)
ConstrainViews(500, format: "V:[view1]-[view2]", views: blueview, redview)

import XCPlayground
backdrop.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.961, alpha: 1.0)
XCPlaygroundPage.currentPage.liveView = backdrop
