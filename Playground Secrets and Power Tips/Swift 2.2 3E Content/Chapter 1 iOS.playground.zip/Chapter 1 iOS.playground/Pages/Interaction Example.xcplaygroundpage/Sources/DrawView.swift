import UIKit

public class DrawView: UIView {
    public var path = UIBezierPath()
    
    override public func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        path = UIBezierPath(); path.lineWidth = 2
        guard let touch = touches.first else {return}
        path.moveToPoint(touch.locationInView(self))
        setNeedsDisplay()
    }
    
    override public  func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        guard let touch = touches.first else {return}
        path.addLineToPoint(touch.locationInView(self))
        setNeedsDisplay()
    }
    
    override public func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        guard let touch = touches.first else {return}
        path.addLineToPoint(touch.locationInView(self))
        setNeedsDisplay()
    }
    
    override public func drawRect(rect: CGRect) {
        UIColor.blackColor().set(); path.stroke()
    }
}
