import UIKit
import SpriteKit
import XCPlayground

/// Build Scene and View
let view = SKView(frame:CGRectMake(0, 0, 400, 300))
let center = CGPointMake(200, 150)
let scene = SKScene(size:view.frame.size)
XCPlaygroundPage.currentPage.liveView = view
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
view.presentScene(scene)

var item1 = SKSpriteNode(imageNamed: "cabinet")
item1.position = center
scene.addChild(item1)

// Child belongs to item 1
var cshape = SKShapeNode(circleOfRadius: 40.0)
item1.addChild(cshape)
cshape.position = CGPointMake(0, 30)

var item2 = SKSpriteNode(imageNamed: "cabbage")
item2.position = center
scene.addChild(item2)

// Positioning
// item2.zPosition = -1
item2.zPosition = +1
cshape.zPosition = +2
