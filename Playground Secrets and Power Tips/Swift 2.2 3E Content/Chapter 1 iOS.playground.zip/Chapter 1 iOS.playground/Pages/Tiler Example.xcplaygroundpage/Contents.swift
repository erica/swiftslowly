import UIKit
import XCPlayground

XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

public class ImageTiler : NSObject {
    public var rootImage : UIImage? = nil
    public var hcount : Int = 1 {didSet {if hcount < 1 {hcount = 1}}}
    public var vcount : Int = 1 {didSet {if vcount < 1 {vcount = 1}}}
    public convenience init(_ image : UIImage, _ hcount : Int, _ vcount : Int) {
        self.init()
        rootImage = image; self.hcount = hcount; self.vcount = vcount
    }
    public func tile(h: Int, _ v : Int) -> UIImage? {
        if let rootImage = rootImage {
            let width = rootImage.size.width / CGFloat(hcount)
            let height = rootImage.size.height / CGFloat(vcount)
            UIGraphicsBeginImageContext(CGSizeMake(width, height))
            let context = UIGraphicsGetCurrentContext()
            let dx = width * CGFloat(h); let dy = height * CGFloat(v)
            CGContextTranslateCTM(context, -dx, -dy)
            rootImage.drawAtPoint(CGPointZero)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return image
        }
        return nil
    }
}

let tiler = ImageTiler(UIImage(named:"groddle")!, 15, 1)
let animView = UIImageView(frame:CGRectMake(0, 0, 78, 119))
animView.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.961, alpha: 1)
animView.animationImages = (0...10).map{tiler.tile($0, 0)!}
animView.animationDuration = 0.5
animView.animationRepeatCount = 0
animView.startAnimating()

XCPlaygroundPage.currentPage.liveView = animView

