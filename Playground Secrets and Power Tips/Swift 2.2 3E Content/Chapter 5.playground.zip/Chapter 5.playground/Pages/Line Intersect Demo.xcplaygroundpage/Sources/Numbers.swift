/*

ericasadun.com
Math Types

*/

import Foundation
import QuartzCore

// MARK: Conversion

public protocol FloatConvertible {
    var DoubleValue: Double { get }
    var FloatValue: Float { get }
    var IntValue: Int { get }
    var CGFloatValue: CGFloat { get }
}

extension CGFloat: FloatConvertible {}
extension Float: FloatConvertible {}
extension Double: FloatConvertible {}
extension Int: FloatConvertible {}

public extension CGFloat {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(self.DoubleValue)}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
}

public extension Double {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(self)}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
}

public extension Float {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(Double(self))}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
}

public extension Int {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(Double(self))}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
    public var BoolValue : Bool {return Bool(self)}
}



// MARK: Ranges

extension Int {
    func clamp(interval : ClosedInterval<Int>)  -> Int {
        if interval ~= self {return self}
        if self < interval.start {return interval.start}
        return interval.end
    }
    
    func clamp(minValue : Int, _ maxValue : Int) -> Int {
        return clamp(minValue...maxValue)
    }
    
    func inRange(interval : ClosedInterval<Int>) -> Bool {
        return interval ~= self
    }
}

extension Double {
    func clamp(interval : ClosedInterval<Double>) -> Double {
        if interval ~= self {return self}
        if self < interval.start {return interval.start}
        return interval.end
    }
    
    func clamp(minValue : Double, _ maxValue : Double) -> Double {
        return self.clamp(minValue...maxValue)
    }
    
    func clamp() -> Double {
        return self.clamp(0.0...1.0)
    }
    
    func inRange(interval : ClosedInterval<Double>) -> Bool {
        return interval ~= self
    }
    
    func inRange(minValue : Double, _ maxValue : Double) -> Bool {
        return self.inRange(minValue...maxValue)
    }
}

// MARK: Utility

extension Int {
    func perform(task: ()->()) {
        for _ in 0..<self {task()}
    }
}

