//: # Core Image Filter Examples
import UIKit
import QuartzCore

// Common components
var filter : CIFilter
var transform : CGAffineTransform
var value : NSValue

//: All these filters share some base functionality, in which the filter is established, the defaults set, and the input image added
func establishFilter(name : String, image : UIImage) -> CIFilter {
    var filter = CIFilter(name:name)
    filter.setDefaults()
    filter.setValue(CIImage(CGImage:image.CGImage), forKey: "inputImage")
    return filter
}

//: Baseline image
let image = UIImage(named:"landscape600")
image

//: Add vibrancy, selectively adjusting image saturation while retaining overall tones
filter = establishFilter("CIVibrance", image!)
filter.setValue(1.0, forKey: "inputAmount")
filter.outputImage

//: Desaturate using color controls, creating a black and white rendition
filter = establishFilter("CIColorControls", image!)
filter.setValue(0.0, forKey: "inputSaturation")
filter.outputImage

//: Apply affine transform, in this case a simple rotation
filter = establishFilter("CIAffineTransform", image!)
transform = CGAffineTransformMakeRotation(CGFloat(M_PI_4))
value = NSValue(CGAffineTransform:transform)
filter.setValue(value, forKey: "inputTransform")
filter.outputImage

//: Posterize, reducing the number of colors used to render the image
filter = establishFilter("CIColorPosterize", image!)
filter.outputImage

