import Accelerate
import UIKit

public func VImageBufferWithSize(size : CGSize) -> vImage_Buffer {
    return vImage_Buffer(data: nil, height: UInt(size.height), width: UInt(size.width), rowBytes: Int(4 * size.width))
}

public func VImageBufferWithData(data : NSData, size: CGSize) -> vImage_Buffer {
    var buffer = VImageBufferWithSize(size)
    buffer.data = unsafeBitCast(data.bytes, UnsafeMutablePointer<Void>.self)
    return buffer
}

public func ImageFromVImageBuffer(var buffer : vImage_Buffer) -> UIImage? {
    var format = vImage_CGImageFormat(
        bitsPerComponent: UInt32(8),
        bitsPerPixel: UInt32(32),
        colorSpace: Unmanaged.passUnretained(CGColorSpaceCreateDeviceRGB()),
        bitmapInfo: CGBitmapInfo(CGImageAlphaInfo.First.rawValue),
        version: UInt32(0),
        decode: nil,
        renderingIntent: kCGRenderingIntentDefault)
    var error = vImage_Error()
    if let unmanagedImageRef = vImageCreateCGImageFromBuffer(&buffer, &format, nil, nil, vImage_Flags(kvImageNoFlags), &error),
        image = UIImage(CGImage: unmanagedImageRef.takeRetainedValue()) {
            return image
    }
    return nil
}

public func VImageBufferWithImage(image : UIImage) -> vImage_Buffer {
    var format = vImage_CGImageFormat(
        bitsPerComponent: UInt32(8),
        bitsPerPixel: UInt32(32),
        colorSpace: Unmanaged.passUnretained(CGImageGetColorSpace(image.CGImage)),
        bitmapInfo: CGBitmapInfo(CGImageAlphaInfo.First.rawValue),
        version: UInt32(0),
        decode: nil,
        renderingIntent: kCGRenderingIntentDefault)
    var bufferPtr = UnsafeMutablePointer<vImage_Buffer>.alloc(1)
    vImageBuffer_InitWithCGImage(bufferPtr, &format, nil, image.CGImage, vImage_Flags(kvImageNoFlags));
    var buffer = bufferPtr.memory
    free(bufferPtr)
    return buffer
}

public func BytesFromImage(image : UIImage ) -> NSData {
    var buffer = VImageBufferWithImage(image)
    var data = NSData(bytes: unsafeBitCast(buffer, UnsafePointer<Void>.self), length: Int(vImagePixelCount(buffer.rowBytes) * buffer.height))
    return data
}

public func ImageFromBytes(data : NSData, size: CGSize) -> UIImage? {
    var buffer = VImageBufferWithData(data, size)
    return ImageFromVImageBuffer(buffer)
}

public func DataFromInt16Kernel(var source: [Int16]) -> NSData {
    return NSData(bytes:&source, length: sizeof(Int16) * source.count)
}

public func KernelFromData(var source: NSData) -> [Int16] {
    let count = source.length / sizeof(Int16)
    var array = [Int16](count: count, repeatedValue:0)
    source.getBytes(&array, length:source.length)
    return array
}

public func LikelyDivisor(kernel : [Int16]) -> Int32 {
    var sum = 0; for each in kernel {sum += Int(each)}
    if sum == 0 {return Int32(1)}
    return Int32(sum)
}

public func Convolve(var kernel: [Int16])(_ image : UIImage) -> UIImage? {
    var inVBuffer = VImageBufferWithImage(image)
    var outVBuffer = VImageBufferWithSize(image.size)
    let byteCount = Int(vImagePixelCount(outVBuffer.rowBytes) * outVBuffer.height)
    outVBuffer.data = malloc(byteCount)
    var backColor : [UInt8] = [0xFF, 0, 0, 0]
    let kernelSize : UInt32 = UInt32(sqrt(Double(kernel.count)))
    
    let error = vImageConvolve_ARGB8888(
        &inVBuffer, &outVBuffer, nil,
        vImagePixelCount(0), vImagePixelCount(0),
        &kernel, kernelSize, kernelSize,
        LikelyDivisor(kernel), // can just sub 1 if needed
        &backColor,
        vImage_Flags(kvImageBackgroundColorFill))
    
    var result : UIImage? = nil
    
    if error == kvImageNoError {
        result = ImageFromVImageBuffer(outVBuffer)
    } else {
        println("Error convolving image")
    }
    
    free(outVBuffer.data)
    return result
}

//public func Convolve(var kernel: [Int16], image : UIImage) -> UIImage? {
//    return Convolve(kernel)(image)
//}
//
//public func CreateConvolve(kernel : [Int16]) -> UIImage -> UIImage? {
//    return {(image : UIImage) -> UIImage? in
//        return Convolve(kernel, image)}
//}

public var embossKernel : [Int16] = [
    -2, -1, 0,
    -1, 1, 1,
    0, 1, 2]
public let Emboss = Convolve(embossKernel)

public var sharpenKernel : [Int16] = [
    0,  -1, 0,
    -1,  8, -1,
    0,  -1, 0
]
public let Sharpen = Convolve(sharpenKernel)

public var blur3Kernel : [Int16] = [Int16](count: 9, repeatedValue:1)
public let Blur3 = Convolve(blur3Kernel)

public var blur5Kernel : [Int16] = [Int16](count: 25, repeatedValue:1)
public let Blur5 = Convolve(blur5Kernel)

public var blur7Kernel : [Int16] = [Int16](count: 49, repeatedValue:1)
public let Blur7 = Convolve(blur7Kernel)

public var gauss5Kernel : [Int16] = [
    1,  4,  6,  4, 1,
    4, 16, 24, 16, 4,
    6, 24, 36, 24, 6,
    4, 16, 24, 16, 4,
    1,  4,  6,  4, 1
]
public let Gauss5 = Convolve(gauss5Kernel)

