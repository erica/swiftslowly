import UIKit

public func timetest(block : ()->()) {
    let date = NSDate()
    block()
    let timeInterval = NSDate().timeIntervalSinceDate(date)
    print("Elapsed time: \(timeInterval)")
}

public struct SpirographGenerator : GeneratorType {
    
    public var pointOffset, dTheta, dR, minorRadius, majorRadius : Double
    public var theta = 0.0
    public typealias Element = CGPoint
    
    public init(
        majorRadius : Double,
        minorRadius : Double,
        pointOffset : Double,
        samples : Double)
    {
        self.pointOffset = pointOffset
        self.dTheta = Double(M_PI) * 2.0 / samples
        self.majorRadius = majorRadius
        self.minorRadius = minorRadius
        self.dR = majorRadius - minorRadius
    }
    
    public mutating func next() -> CGPoint? {
        let xT : Double = dR * cos(theta) + pointOffset * cos(dR * theta / minorRadius)
        let yT : Double = dR * sin(theta) + pointOffset * sin (dR * theta / minorRadius)
        theta = theta + dTheta
        return CGPoint(x: xT, y: yT)
    }
}


public func Spirograph(
    size : CGSize,
    samples : Double,
    minor : Double,
    offset: Double) -> UIImage {
        
        // Calculate major radius from output width
        var major = Double(lrint(Double(size.width) / 4.0))
        major = floor(major / minor) * minor
        
        // Establish generator and first point
        var spiro = SpirographGenerator(majorRadius:major, minorRadius:minor, pointOffset:offset, samples:samples)
        var current : CGPoint! = spiro.next()
        
        
        // Draw into image
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        CGContextTranslateCTM(UIGraphicsGetCurrentContext(), size.width / 2.0, size.height / 2.0)
        UIColor.blackColor().set()
        
        // Iterate through samples
        for _ in 1...Int(samples) {
            let path = UIBezierPath()
            path.moveToPoint(current)
            current = spiro.next()
            path.addLineToPoint(current)
            path.stroke()
        }
        
        // Fetch and return image
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
}

