import UIKit

var image = Spirograph(CGSizeMake(600, 600), samples: 2048, minor: -2, offset: 130)
