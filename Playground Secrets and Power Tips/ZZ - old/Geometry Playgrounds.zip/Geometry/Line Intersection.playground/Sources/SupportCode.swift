import UIKit
import QuartzCore

public func RandomPosition(maxpos : UInt32)  -> CGFloat {return CGFloat(arc4random_uniform(maxpos))}

public func RectAroundCenter(center : CGPoint, size:CGSize) -> CGRect {
    let origin = CGPointMake(center.x - size.width / 2.0, center.y - size.height / 2)
    return CGRect(origin: origin, size: size)}

public extension UIBezierPath {
    public convenience init(_ point : CGPoint) {
        self.init(point:point, radius:6.0)
    }
    
    public convenience init(_ p1 : CGPoint, _ p2: CGPoint) {
        self.init()
        self.moveToPoint(p1)
        self.addLineToPoint(p2)
    }
    
    public convenience init(point : CGPoint, radius : CGFloat) {
        self.init()
        let rect = RectAroundCenter(point, CGSizeMake(radius * 2.0, radius * 2.0))
        self.appendPath(UIBezierPath(ovalInRect: rect))
    }
    
    public func addPointMarker(point : CGPoint, radius: CGFloat) {
        let rect = RectAroundCenter(point, CGSizeMake(radius * 2.0, radius * 2.0))
        self.appendPath(UIBezierPath(ovalInRect: rect))
    }
    
    public func addLine(p1 : CGPoint, p2: CGPoint) {
        let line = UIBezierPath()
        line.moveToPoint(p1)
        line.addLineToPoint(p2)
        self.appendPath(line)
    }
}

