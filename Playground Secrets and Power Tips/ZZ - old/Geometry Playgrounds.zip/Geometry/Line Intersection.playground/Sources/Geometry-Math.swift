/*

ericasadun.com
Requires Numbers.swift

*/

import Foundation
import QuartzCore
import UIKit

// Vectors

public extension CGPoint {
    public var vectorForm : CGVector {return CGVectorMake(self.x, self.y)}
}

public extension CGVector {
    public var magnitude : CGFloat {
        return sqrt((self.dx * self.dx) + (self.dy * self.dy))
    }
}

public func * <T:FloatConvertible>(lhs : CGVector, rhs: T) -> CGVector {
    let scale = rhs.DoubleValue
    let dx = lhs.dx.DoubleValue * rhs.DoubleValue
    let dy = lhs.dy.DoubleValue * rhs.DoubleValue
    return CGVectorMake(dx.CGFloatValue, dy.CGFloatValue)
}

public func / <T:FloatConvertible>(lhs : CGVector, rhs: T) -> CGVector {
    let scale = rhs.DoubleValue
    let dx = lhs.dx.DoubleValue / rhs.DoubleValue
    let dy = lhs.dy.DoubleValue / rhs.DoubleValue
    return CGVectorMake(dx.CGFloatValue, dy.CGFloatValue)
}

// Sizes

public func * <T:FloatConvertible>(lhs : CGSize, rhs: T) -> CGSize {
    let scale = rhs.DoubleValue
    let width = lhs.width.DoubleValue * rhs.DoubleValue
    let height = lhs.height.DoubleValue * rhs.DoubleValue
    return CGSizeMake(width.CGFloatValue, height.CGFloatValue)
}

public func / <T:FloatConvertible>(lhs : CGSize, rhs: T) -> CGSize {
    let scale = rhs.DoubleValue
    let width = lhs.width.DoubleValue / rhs.DoubleValue
    let height = lhs.height.DoubleValue / rhs.DoubleValue
    return CGSizeMake(width.CGFloatValue, height.CGFloatValue)
}

// Points

public func - (lhs : CGPoint, rhs : CGPoint) -> CGVector {
    return CGVectorMake(lhs.x - rhs.x, lhs.y - rhs.y)
}

public func + (lhs : CGPoint, rhs : CGVector) -> CGPoint {
    return CGPointMake(lhs.x + rhs.dx, lhs.y + rhs.dy)
}

public func - (lhs : CGPoint, rhs : CGVector) -> CGPoint {
    return CGPointMake(lhs.x - rhs.dx, lhs.y - rhs.dy)
}

// Rects

public func + (lhs : CGRect, rhs: CGPoint) -> CGRect {
    return CGRectOffset(lhs, rhs.x, rhs.y)
}

public func * (lhs : CGRect, rhs: FloatConvertible) -> CGRect {
    return CGRect(origin: lhs.origin, size: (lhs.size * rhs.CGFloatValue))
}

// Dot product

infix operator • { associativity left } // regular
infix operator •• { associativity left } // normalized
infix operator ** { associativity left } // normalized

public func • (lhs : CGVector, rhs : CGVector) -> CGFloat {
    var dot : CGFloat = (lhs.dx * rhs.dx) + (lhs.dy * rhs.dy)
    return dot;
}

public func * (lhs : CGVector, rhs : CGVector) -> CGFloat {
    return lhs • rhs
}

public func •• (lhs : CGVector, rhs : CGVector) -> CGFloat {
    var dot : CGFloat = (lhs.dx * rhs.dx) + (lhs.dy * rhs.dy)
    dot /= (lhs.magnitude * rhs.magnitude)
    return dot;
}

public func ** (lhs : CGVector, rhs : CGVector) -> CGFloat {
    return lhs •• rhs
}

public struct Segment {

    public var p1 : CGPoint
    public var p2 : CGPoint

    public init(p1 : CGPoint, p2 : CGPoint) {
        self.p1 = p1
        self.p2 = p2
    }

    public var slope : CGFloat {return (p2.y - p1.y) / (p2.x - p1.x)}
    
    public var length : CGFloat {
        let p = CGPointMake(p2.x - p1.x, p2.y - p1.y)
        return sqrt(p.x * p.x + p.y * p.y)
    }
    
    public func pointAtPercent(percent : CGFloat) -> CGPoint {
        return CGPointMake(p1.x + (p2.x - p1.x) * percent, p1.y + (p2.y - p1.y) * percent)
    }
    
    public var midpoint : CGPoint {
        return self.pointAtPercent(0.5)
    }
    
    public var vector : CGVector {
        return p2 - p1
    }
}

public extension UIBezierPath {
    public convenience init(_ segment : Segment) {
        self.init()
        self.moveToPoint(segment.p1)
        self.addLineToPoint(segment.p2)
    }
    
    public convenience init(dottedSegment segment: Segment) {
        self.init(segment)
        self.appendPath(UIBezierPath(point: segment.p1, radius: 6))
        self.appendPath(UIBezierPath(point: segment.p2, radius: 6))
    }
}

public extension CGPoint {
    public func projectedToLine(segment : Segment) -> CGPoint {
        let lengthSquared = segment.length * segment.length
        let vectorAB = segment.p2 - segment.p1
        let vectorAP = self - segment.p1
        let t = (vectorAP.dx * vectorAB.dx + vectorAP.dy * vectorAB.dy) / lengthSquared
        let projection = segment.p1 + vectorAB * t
        return projection
    }
    
    public func distanceToLine(segment : Segment) -> CGFloat {
        let projected = projectedToLine(segment)
        return Segment(p1: self, p2: projected).length
    }
    
    public func distanceToPoint(point : CGPoint) -> CGFloat {
        return Segment(p1:self, p2:point).length
    }
    
    public func mirroredAcrossLine(segment: Segment) -> CGPoint {
        let intersection = projectedToLine(segment)
        return intersection + (intersection - self)
    }
    
    public func projectedOntoPerpendicular(segment: Segment) -> CGPoint {
        let midpoint = segment.midpoint
        let intersection = self.projectedToLine(segment)
        let vector = self - intersection
        return midpoint + vector
    }
    
    public func mirroredAcrossPerpendicular(segment: Segment) -> CGPoint {
        let perpPoint = self.projectedOntoPerpendicular(segment)
        let midline = Segment(p1:perpPoint, p2:segment.midpoint)
        return self.mirroredAcrossLine(midline)
    }
}

public extension Segment {
    public func halfPlane(p : CGPoint) -> CGFloat {
        let dx = p2.x - p1.x
        let dy = p2.y - p1.y
        let tx = p.x - p1.x
        let ty = p.y - p1.y
        return dx*ty - tx*dy
    }

    public func crossesSegment(segment : Segment) -> Bool {
        if CGPointEqualToPoint(self.p1, segment.p1) {return true}
        if CGPointEqualToPoint(self.p1, segment.p2) {return true}
        if CGPointEqualToPoint(self.p2, segment.p1) {return true}
        if CGPointEqualToPoint(self.p2, segment.p2) {return true}
        
        let hp1 = halfPlane(segment.p1) < 0.0
        let hp2 = halfPlane(segment.p2) < 0.0
        
        let hp3 = segment.halfPlane(p1) < 0.0
        let hp4 = segment.halfPlane(p2) < 0.0
        
        if hp1 == hp2 {return false}
        if hp3 == hp4 {return false}
        return true
    }
    
    public func intersectionWithLine(segment : Segment) -> CGPoint? {
        if !crossesSegment(segment) {return nil}
        let tx = (p1.x * p2.y - p1.y * p2.x) * (segment.p1.x - segment.p2.x) - (segment.p1.x * segment.p2.y - segment.p1.y * segment.p2.x) * (p1.x - p2.x);
        let ty = (p1.x * p2.y - p1.y * p2.x) * (segment.p1.y - segment.p2.y) - (segment.p1.x * segment.p2.y - segment.p1.y * segment.p2.x) * (p1.y - p2.y);
        let d = (p1.x - p2.x) * (segment.p1.y - segment.p2.y) - (p1.y - p2.y) * (segment.p1.x - segment.p2.x);
        return CGPointMake(tx / d, ty / d);
    }
    
    public func centerWithRadius(radius: CGFloat, clockwise : Bool) -> CGPoint? {
        let pa = clockwise ? p1 : p2
        let pb = clockwise ? p2 : p1
        let segment = Segment(p1: pa, p2: pb)

        let diameter = radius * 2.0
        if segment.length > diameter {return nil}
        
        let midpoint = segment.midpoint
        let x = midpoint.x + sqrt(pow(radius, 2) - pow(segment.length / 2.0, 2)) * (pa.y - pb.y) / segment.length
        let y = midpoint.y + sqrt(pow(radius, 2) - pow(segment.length / 2.0, 2)) * (pb.x - pa.x) / segment.length
        return CGPointMake(x, y)
    }
}