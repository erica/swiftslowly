import UIKit
//: # Line Intersection Demo
var image : UIImage!
let sideLength : CGFloat = 250.0
let random = {RandomPosition(UInt32(sideLength))}

//: Populate an array with random line segments
var segments = [Segment]()
for index in 1...6 {
    let seg = Segment(
        p1: CGPointMake(random(), random()),
        p2: CGPointMake(random(), random()))
    segments += [seg]
}
//: The chance of intersection increases and decreases in lock step with the number of segments. Try tweaking this number up and down from 6 to see how the results vary.
// The half-plane test stretches each line segment to infinity and tests whether both endpoints of a second segment appear on the same side of that line. If so, the two do not intersect. 
image = DrawImage(CGSizeMake(sideLength, sideLength)){
    // Draw each line
    for seg in segments{UIBezierPath(dottedSegment:seg).performDraw()}

    // Check pairwise for intersections
    for (i, s1) in enumerate(segments) {
      for s2 in segments[i+1..<segments.count] {
          if let xp = s1.intersectionWithLine(s2) {
              UIBezierPath(xp).strokeWithColor(.redColor(), width:3)}}}
}

image


//: Re-execute this playground with new random segments by choosing Editor > Execute Playground
