import AppKit
import XCPlayground
/*:
### Sample OS X App
This playground builds a minimal interactive OS X application

Uncomment out the following line of code to get started
*/
XCPSetExecutionShouldContinueIndefinitely(continueIndefinitely: true)
/*:
To run properly, this app requires a backing run loop. Set the
execution duration to a nice long time, such as a minute or two using
the *time-to-live* control at the very bottom right of the playground.
The playground automatically ends execution after this time. If you're
wondering why your well-behaved apps suddenly quit on you, that is why.

The details for window creation and presentation are established in the 
SupportCode.swift file.

    public func BuildOSXWindow(size : CGSize) -> NSWindow {
        let window = NSWindow(
            contentRect: CGRect(origin : CGPointZero, size:size),
            styleMask: NSTitledWindowMask | NSResizableWindowMask | NSMiniaturizableWindowMask | NSClosableWindowMask,
        backing: .Buffered,
        defer: false)
        window.hasShadow = true
        window.level = 7 // Constants seem to be MIA
        return window
    }

This function takes two arguments. The first sets the size of the window, the second
establishes where on the screen to present the window, so it doesn't get lost. The
window presents at a fairly high priority to allow it to float *over* the 
playground. Without this setting, the window would keep getting stuck behind the 
playground editor workspace.

This call creates an `NSWindow` instance and presents it,
ordering it front and making it key*/
PresentWindow(CGSizeMake(300, 200), CGPointMake(1000, 800))
mainwindow.title = "Converter"
/*:
The following code populates the window with a pair of labels and text fields. These include an input set (Fahrenheit) and output set (Celsius)
*/
let flabel = BuildAndAddTextLabel("Fahrenheit", CGSizeMake(65, 16))
let ftextField = BuildAndAddTextField(CGSizeMake(150, 24))
let clabel = BuildAndAddTextLabel("Celsius", CGSizeMake(65, 16))
let ctextField = BuildAndAddTextField(CGSizeMake(150, 24))
/*:
The output text field is non-editable and uses a maximum of 2 digits to present its results
*/
ctextField.editable = false
let formatter = NSNumberFormatter()
formatter.numberStyle = .DecimalStyle
formatter.maximumFractionDigits = 2
ctextField.formatter = formatter
/*:
The Constraint MiniPack library, which is included in the Playground sources, simplifies the field layout to just a few calls.
*/
for format in ["H:|-30-[view1]-[view2]", "H:|-30-[view3]-[view4]", "V:|-40-[view2]-[view4]"] {
    ConstrainViews(500, format, [:], [flabel, ftextField, clabel, ctextField])
}
AlignViews(500, flabel, ftextField, .CenterY)
AlignViews(500, clabel, ctextField, .CenterY)
/*:
For the app to do anything meaningful, in this case convert temperatures between Fahrenheit and Celsius, it needs a client that reacts to text field updates and calculates output values. The following minimal Delegate class takes charge of that, populating the Celsius text field.
*/
// Add App Functionality
class Delegate : NSObject, NSTextFieldDelegate {
    override func controlTextDidChange(note: NSNotification) {
        if let field = note.object as? NSTextField {
            let f = field.doubleValue
            let c = (f - 32.0) * 5.0 / 9.0
            ctextField.stringValue = "\(c)"
        }
    }
}
var delegate = Delegate()
ftextField.delegate = delegate
/*:
Finally, just to show that extra functionality is possible, the following code adds minimal "About" support. When clicked, the button calls the `about()` method in the Delegate class extension. The text for the About box is stored in the playground Resources folder.
*/
extension Delegate {
    func about() {
        NSApp.orderFrontStandardAboutPanel(nil)
    }
}
let button = NSButton(); mainwindow.contentView.addSubview(button); button.title = "About"
button.action = "about"; button.target = delegate; button.bezelStyle = .RoundedBezelStyle
SizeView(button, CGSizeMake(80, 20), 500)
PlaceViewInSuperview(button, "br", 20, 20, 500)
