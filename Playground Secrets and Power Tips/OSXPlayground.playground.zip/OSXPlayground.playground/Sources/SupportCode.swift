import Cocoa
import AppKit

// MARK: Main OSX Window

public func BuildOSXWindow(size : CGSize) -> NSWindow {
    let window = NSWindow(
        contentRect: CGRect(origin : CGPointZero, size:size),
        styleMask: NSTitledWindowMask | NSResizableWindowMask | NSMiniaturizableWindowMask | NSClosableWindowMask,
        backing: .Buffered,
        defer: false)
    window.hasShadow = true
    window.level = 7 // Constants seem to be MIA
    return window
}

public var mainwindow = NSWindow()

public func PresentWindow(size: CGSize, position: CGPoint) {
    mainwindow = BuildOSXWindow(size)
    mainwindow.setFrameOrigin(position)
    NSApplication.sharedApplication().setActivationPolicy(.Regular) // Thanks Mike Ash
    mainwindow.makeKeyAndOrderFront(nil)
}

// MARK: Building Utilities

public func BuildAndAddTextField(size : CGSize) -> NSTextField {
    let textField = NSTextField()
    textField.autoLayoutEnabled = true
    SizeView(textField, size, 1000)
    mainwindow.contentView.addSubview(textField);
    textField.editable = true
    return textField
}

public func BuildAndAddTextLabel(text : String, size : CGSize) -> NSTextField {
    let textField = NSTextField()
    textField.autoLayoutEnabled = true
    SizeView(textField, size, 1000)
    mainwindow.contentView.addSubview(textField);
    textField.stringValue = text
    textField.bezeled = false
    textField.drawsBackground = false
    textField.editable = false
    textField.selectable = false
    return textField
}