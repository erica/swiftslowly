import Cocoa

// Support Foundation calls on String
public extension String { public var ns: NSString {return self as NSString} }

/// Custom Labeled Playground-Based Drag-and-Drop window
public class DropView: NSTextField {
    
    // Default action handler
    public var handler: ([String]) -> Void = { paths in Swift.print(paths) }

    // Drag and drop notification
    public override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { return NSDragOperation.copy }
    public override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation { return NSDragOperation.copy }
    public override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let pboard = sender.draggingPasteboard()
        guard let paths = pboard.propertyList(forType: NSFilenamesPboardType) as? [String] else { return false }
        handler(paths)
        return true
    }
    
    public required init?(coder: NSCoder) { super.init(coder: coder) }
    public override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        
        // Presentation
        stringValue = "Drop Here"; isEditable = false
        font = NSFont(name: "Palatino", size: 48.0); alignment = .center
        wantsLayer = true; layer?.backgroundColor = NSColor.white().cgColor

        // Register for file name drags
        register(forDraggedTypes: [NSFilenamesPboardType])
    }
}
