/*
 
 ericasadun.com
 
 */

import UIKit

public typealias BezierPath = UIBezierPath

public func BezierStarShape(inflections: Int, length: CGFloat, percent: CGFloat) -> BezierPath {
    
    if inflections < 3 {
        return BezierPath(ovalIn: CGRect(x: 0.0, y: 0.0, width: length, height: length))
    }
    
    let π = CGFloat(Darwin.M_PI)
    let path = BezierPath()
    let center = CGPoint(x: length, y: length)
    let radius: CGFloat = length
    let rradius = radius * percent
    
    var firstPoint = true
    for inflection in 0...(inflections - 1) {
        let theta = π + CGFloat(inflection) * 2.0 * π / CGFloat(inflections)
        let dTheta = 2.0 * π / CGFloat(inflections)
        
        var p = CGPoint.zero
        if firstPoint {
            p.x = center.x + radius * CGFloat(cos(theta))
            p.y = center.y + radius * CGFloat(sin(theta))
            path.move(to: p)
            firstPoint = false
        }
        
        let cp1x = center.x + rradius * cos(theta + dTheta / 2.0)
        let cp1y = center.y + rradius * sin(theta + dTheta / 2.0)
        let cp1 = CGPoint(x: cp1x, y: cp1y)
        
        p.x = center.x + radius * CGFloat(cos(theta + dTheta))
        p.y = center.y + radius * CGFloat(sin(theta + dTheta))
        path.addLine(to: cp1)
        path.addLine(to: p)
    }
    path.close()
    return path
}
