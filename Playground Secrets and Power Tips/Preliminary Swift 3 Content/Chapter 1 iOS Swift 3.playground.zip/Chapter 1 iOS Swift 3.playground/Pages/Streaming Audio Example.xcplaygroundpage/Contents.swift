import UIKit
import AVFoundation
import PlaygroundSupport
/*
 NBhosting: anyone able to show me an example how to play a live stream like http://108.61.73.120:8126/;stream/1
 */

PlaygroundPage.current.needsIndefiniteExecution = true
let streamrequest = "http://108.61.73.120:8126/;stream/1"
let asset = AVAsset(url: URL(string: streamrequest)!)
let item = AVPlayerItem(asset: asset)
let player = AVPlayer(playerItem: item)
player.play()
