import UIKit
import SpriteKit
import PlaygroundSupport

/// Build Scene and View
let view = SKView(frame:CGRect(x: 0, y: 0, width: 400, height: 300))
let center = CGPoint(x: 200, y: 150)
let scene = SKScene(size:view.frame.size)
PlaygroundPage.current.liveView = view
PlaygroundPage.current.needsIndefiniteExecution = true
view.presentScene(scene)

var item1 = SKSpriteNode(imageNamed: "cabinet")
item1.position = center
scene.addChild(item1)

// Child belongs to item 1
var cshape = SKShapeNode(circleOfRadius: 40.0)
item1.addChild(cshape)
cshape.position = CGPoint(x: 0, y: 30)

var item2 = SKSpriteNode(imageNamed: "cabbage")
item2.position = center
scene.addChild(item2)

// Positioning
// item2.zPosition = -1
item2.zPosition = +1
cshape.zPosition = +2
