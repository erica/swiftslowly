import Foundation

1 + 1

let x = 59
x + 22

func isEven(number: Int) -> Bool {
    return (number % 2) == 0
}

isEven(number: x)
isEven(number: x + 1)
