import Foundation

var searchString = "Test Phrase"
let queryString = "client=firefox&q=\(searchString)".addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed())!
let requestString = "http://suggestqueries.google.com/complete/search?\(queryString)"
let data = NSData(contentsOf: URL(string: requestString)!)! as Data
let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments])

for each in json[1] as! [String] {
    each
}
