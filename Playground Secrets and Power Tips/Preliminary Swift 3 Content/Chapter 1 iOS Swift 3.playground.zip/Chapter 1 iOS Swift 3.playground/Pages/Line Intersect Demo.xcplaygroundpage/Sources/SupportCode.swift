import UIKit
import QuartzCore

public func RandomPosition(maxpos : UInt32)  -> CGFloat {return CGFloat(arc4random_uniform(maxpos))}

public func RectAroundCenter(center : CGPoint, size:CGSize) -> CGRect {
    let origin = CGPoint(x: center.x - size.width / 2.0, y: center.y - size.height / 2)
    return CGRect(origin: origin, size: size)}

public extension UIBezierPath {
    public convenience init(_ point : CGPoint) {
        self.init(point:point, radius:6.0)
    }
    
    public convenience init(_ p1 : CGPoint, _ p2: CGPoint) {
        self.init()
        self.move(to: p1)
        self.addLine(to: p2)
    }
    
    public convenience init(point : CGPoint, radius : CGFloat) {
        self.init()
        let rect = RectAroundCenter(center: point, size: CGSize(width: radius * 2.0, height: radius * 2.0))
        self.append(UIBezierPath(ovalIn: rect))
    }
    
    public func addPointMarker(point : CGPoint, radius: CGFloat) {
        let rect = RectAroundCenter(center: point, size: CGSize(width: radius * 2.0, height: radius * 2.0))
        self.append(UIBezierPath(ovalIn: rect))
    }
    
    public func addLine(p1 : CGPoint, p2: CGPoint) {
        let line = UIBezierPath()
        line.move(to: p1)
        line.addLine(to: p2)
        self.append(line)
    }
}

