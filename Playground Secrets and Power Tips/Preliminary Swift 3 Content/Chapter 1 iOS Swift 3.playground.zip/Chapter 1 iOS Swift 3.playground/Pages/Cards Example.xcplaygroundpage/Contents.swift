import Foundation
import UIKit

public enum Suit: Int, CustomStringConvertible {
    case Clubs = 1, Diamonds, Hearts, Spades
    public var description: String {
        return ["♣️", "♦️", "❤️", "♠️"][rawValue - 1]
    }
    public var nativeColor: UIColor {
        switch self {
        case .Clubs, .Spades: return .black()
        default: return .red()
        }
    }
}

public enum Rank: Int, CustomStringConvertible {
    case Ace = 1, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King
    public var description: String {
        return ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"][rawValue - 1]
    }
}

public struct Card: CustomPlaygroundQuickLookable {
    public let deckString = "🃑🃒🃓🃔🃕🃖🃗🃘🃙🃚🃛🃝🃞🃁🃂🃃🃄🃅🃆🃇🃈🃉🃊🃋🃍🃎🂱🂲🂳🂴🂵🂶🂷🂸🂹🂺🂻🂽🂾🂡🂢🂣🂤🂥🂦🂧🂨🂩🂪🂫🂭🂮"
    public let rawValue: Int; let suit: Suit; let rank: Rank
    
    public init(_ rawValue: Int) {
        assert(0..<52 ~= rawValue)
        self.rawValue = rawValue
        suit = Suit(rawValue: 1 + (rawValue  / 13))!
        rank = Rank(rawValue:  1 + (rawValue % 13))!
    }
    
    public init(_ rank: Rank, _ suit: Suit) {
        let r = rank.rawValue - 1
        let s = suit.rawValue - 1
        self.init(s * 13 + r)
    }
    
    public var faceString: AttributedString {
        let idx = deckString.characters.index(deckString.startIndex, offsetBy: rawValue)
        let idxEnd = deckString.characters.index(deckString.startIndex, offsetBy: rawValue + 1)
        let cardFace = deckString.substring(with: idx ..< idxEnd)
        return AttributedString(string: cardFace, attributes: [
            NSForegroundColorAttributeName: suit.nativeColor,
            NSFontAttributeName: UIFont(name:"Helvetica Neue", size: 96.0)!
        ])
    }
    
    public var customPlaygroundQuickLook : PlaygroundQuickLook {
        return PlaygroundQuickLook.attributedString(faceString)
    }
}
let king = Card(.King, .Spades).faceString.mutableCopy()
king.insert(AttributedString.init(string: "\n"), at: 0)
king
let s = NSMutableAttributedString(string: "\n", attributes: [:])
for item in [Card(.Queen, .Hearts), Card(.Jack, .Spades), Card(.Two, .Clubs), Card(.Five, .Diamonds)] {
    s.append(item.faceString)
}
s
