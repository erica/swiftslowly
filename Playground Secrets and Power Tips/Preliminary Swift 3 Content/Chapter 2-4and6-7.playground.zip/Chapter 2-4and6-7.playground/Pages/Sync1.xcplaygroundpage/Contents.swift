import Foundation
import PlaygroundSupport

// Establish indefinite execution
PlaygroundPage.current.needsIndefiniteExecution = true

print("Starting")
DispatchQueue.main.after(when: DispatchTime.now() + Double(Int64(2.0 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC),
                         execute: {
                            print("Finished!")
                            PlaygroundPage.current.finishExecution()
    }
)
