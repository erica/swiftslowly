import Foundation

extension String {
    var ns: NSString { return self as NSString }
}

fileManager

print(myDocumentsFolder)
establishMyDocumentsFolder()
establishMyDocumentsFolder()
print(playgroundDocumentsFolder)

