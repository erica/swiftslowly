/*
 
 ericasadun.com
 Playground Support: Add to playground's Sources folder
 
 */

import Foundation
import PlaygroundSupport

// Convenience
public let fileManager = FileManager.default()

//------------------------------------------------------------------------------
// MARK: Process Info
// Return information about the playground process and the environment
// it is running within
//------------------------------------------------------------------------------

/// Access the playground's process info
public let processInfo = ProcessInfo.processInfo()

/// The playground's environmental variables
public let processEnvironment = processInfo.environment

/// Keys in the environment dictionary for quick reference
public let environmentKeys = Array(processInfo.environment.keys)

/// Playground name (Used later to create a private documents folder)
public let playgroundName: String = ProcessInfo.processInfo().processName as String

// Path to the playground's sandbox container
#if os(OSX)
    public let playgroundContainerPath: String = NSHomeDirectory()
        .ns.stringByDeletingLastPathComponent
#else
    // iOS, tvOS, watchOS
    public let playgroundContainerPath: String = (processEnvironment["PLAYGROUND_SANDBOX_CONTAINER_PATH"] ?? "?") as String
#endif

//------------------------------------------------------------------------------
// MARK: Application
// Return information about the pseudo-app that the playground builds/executes
// Note: I'd like a real-world path to Resources (path-to-playground/Resources)
// but I don't think that's going to happen with sandboxing enabled
//------------------------------------------------------------------------------

/// Path to the playground's bundle and resources
/// At this time, they are identical on iOS (but not OS X)
public let bundlePath = Bundle.main().bundlePath
public let resourcePath = Bundle.main().resourcePath ?? bundlePath

/// Bundle and Resource contents if available
public let bundleContents = try! fileManager.contentsOfDirectory(atPath: bundlePath)
public let resourceContents = try! fileManager.contentsOfDirectory(atPath: resourcePath)

/// Application Executable Path
public let executablePath: String! = Bundle.main().executablePath

// NSString support
extension String { var ns: NSString { return self as NSString } }

/// Application .app Bundle Path
#if os(iOS)
    public let appPath = executablePath
        .ns.deletingLastPathComponent
#else
    public let appPath = executablePath
        .ns.deletingLastPathComponent
        .ns.deletingLastPathComponent
        .ns.deletingLastPathComponent
#endif

/// Playground Application Name
public let appName = (bundlePath as NSString).lastPathComponent

/// Access to the bundle's Info.plist dictionary
public let infoDictionary = Bundle.main().infoDictionary

//------------------------------------------------------------------------------
// MARK: Shared Data Folder
// The shared playground data in the user Documents foler
//------------------------------------------------------------------------------

/// The document path INSIDE THE SANDBOX
public let documentPath = NSSearchPathForDirectoriesInDomains(
    .documentDirectory, .userDomainMask, true)[0] as NSString
public let sharedDataPath = documentPath
    .appendingPathComponent("Shared Playground Data") as NSString

/// The Shared Playground Data folder OUTSIDE THE SANDBOX
public let sharedDataFolder = (processEnvironment["PLAYGROUND_SHARED_DATA_FOLDER"] ?? "~/Documents/Shared Playground Data") as String


//------------------------------------------------------------------------------
// MARK: Documents
// Return paths to the playground's documents folder by
// stepping down the path from NSHomeDirectory()
//------------------------------------------------------------------------------

#if !os(OSX)
    // The Shared Resources Folder for the simulator
    // Typically ~/Library/Application Support/iPhone Simulator
    public let sharedResourcesFolder = (processEnvironment["IPHONE_SHARED_RESOURCES_DIRECTORY"] ?? "?") as String
#endif

// The shared data from within the documents in the sandbox
public let homeFolder = NSHomeDirectory() as NSString
public let documentsFolder = homeFolder.appendingPathComponent("Documents") as NSString
public let playgroundDocumentFolder = documentsFolder.appendingPathComponent("Shared Playground Data")

//------------------------------------------------------------------------------
// MARK: Custom Subfolder
// A custom subfolder to store this playground's data
// (This is not a default behavior, but meant to keep the
// shared documents folder cleaner)
//------------------------------------------------------------------------------

/// From the shared data into a playground-named subfolder
public let sharedDocsFolder: String = playgroundDocumentsFolder

/// Playground-named Documents folder
public let myDocumentsFolder = sharedDocsFolder
    .ns.appendingPathComponent(playgroundName)

/// Public-named Documents folder
let escapedPlaygroundName = playgroundName.ns.replacingOccurrences(of: " ", with: "\\ ")
public let playgroundDocumentsFolder = "~/Documents/Shared\\ Playground\\ Data/" + escapedPlaygroundName

/// Playground-named Documents URL
public let myDocumentsURL = try! URL(fileURLWithPath: playgroundDocumentsFolder).appendingPathComponent(playgroundName)

/// Establish Playground-Named Documents Folder
public func establishMyDocumentsFolder() {
    do {
        try fileManager.createDirectory(at: myDocumentsURL, withIntermediateDirectories: true, attributes: nil)
    } catch {
        print("Unable to establish folder at", myDocumentsURL)
    }
}

/// Return contents of custom playground-named subfolder
/// The subfolder is created if it does not already exist
public func contentsOfMyDocumentsFolder() throws -> [AnyObject]? {
    if !fileManager.fileExists(atPath: myDocumentsFolder) {establishMyDocumentsFolder()}
    return try fileManager.contentsOfDirectory(atPath: myDocumentsFolder)
}
