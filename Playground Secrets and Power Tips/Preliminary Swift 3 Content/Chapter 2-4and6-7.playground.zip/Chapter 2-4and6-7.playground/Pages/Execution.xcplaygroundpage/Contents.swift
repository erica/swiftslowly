import UIKit
var x = 2
var now = NSDate()
x = 5
