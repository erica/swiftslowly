import UIKit
import PlaygroundSupport

// Create thumb
UIGraphicsBeginImageContext(CGSize(width: 48, height: 48))
let path = UIBezierPath()
path.append(UIBezierPath(roundedRect: CGRect(x: 4, y: 4, width: 40, height: 40), cornerRadius: 8))
path.append(UIBezierPath(ovalIn: CGRect(x: 20, y: 20, width: 8, height: 8)))
path.lineWidth = 4
UIColor.red().set()
path.stroke()
let thumb = UIGraphicsGetImageFromCurrentImageContext()
UIGraphicsEndImageContext()

let SliderKey = "SliderKey"

// Build and tweak slider
let slider = UISlider(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
slider.value = 0.5
slider.minimumTrackTintColor = .green()
slider.maximumTrackTintColor = .orange()
slider.setThumbImage(thumb, for: [])

slider.backgroundColor = .white()
PlaygroundPage.current.liveView = slider
PlaygroundPage.current.needsIndefiniteExecution = true
