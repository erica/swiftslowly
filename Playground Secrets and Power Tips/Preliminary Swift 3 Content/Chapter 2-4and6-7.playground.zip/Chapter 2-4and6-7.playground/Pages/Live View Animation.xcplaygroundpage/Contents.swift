import UIKit
import PlaygroundSupport

class VC: UIViewController {
    let newView = UIView()
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        newView.frame = view.bounds
        newView.backgroundColor = .red()
        UIView.transition(from: view, to: newView, duration: 3.0, options: [.transitionCurlUp], completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green()
    }
}

let vc = VC()
PlaygroundPage.current.liveView = vc
PlaygroundPage.current.needsIndefiniteExecution = true
