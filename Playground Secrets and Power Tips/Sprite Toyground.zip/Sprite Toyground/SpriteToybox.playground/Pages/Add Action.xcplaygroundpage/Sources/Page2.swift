import Foundation
import Cocoa
import SpriteKit
import XCPlayground

public let skview = SKView(frame:CGRectMake(0, 0, 300, 240))
public let center = CGPointMake(150, 120)
public let skscene = SKScene(size:skview.frame.size)
public var sprite = SKShapeNode()

@available (OSX 10.10, *)
public func setup() -> SKShapeNode {
    sprite = SKShapeNode(circleOfRadius: 40)
    skview.presentScene(skscene)
    XCPlaygroundPage.currentPage.liveView = skview
    sprite.lineWidth = 8.0
    if let hue = GetData("hue"),
        hueValue = Double(hue) {
            SpriteColor = NSColor(hue:CGFloat(hueValue), saturation: 0.85, brightness:1.0, alpha:0.5)
    }
    sprite.fillColor = SpriteColor
    sprite.position = center
    skscene.addChild(sprite)
    return sprite
}

