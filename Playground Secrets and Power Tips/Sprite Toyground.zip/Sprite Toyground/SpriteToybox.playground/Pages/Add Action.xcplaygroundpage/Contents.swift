//: [Previous](@previous)
import Cocoa
import SpriteKit
import XCPlayground

setup()
//: # Action!
//: Create some SpriteKit actions, and build a sequence from them
let zoomIn = SKAction.scaleTo(0.6, duration: 1.0)
let zoomOut = SKAction.scaleTo(1.5, duration: 0.75)
let normal = SKAction.scaleTo(1.0, duration: 0.3)
let sequence = SKAction.sequence([zoomIn, zoomOut, normal])
//: Use the toybox button to trigger the action
extension Delegate : TriggerResponder {
    public func itemDidTrigger(identity: String) {
        sprite.runAction(sequence)
    }
}
manager.addTriggerResponder(delegate)
//: [Next](@next)
