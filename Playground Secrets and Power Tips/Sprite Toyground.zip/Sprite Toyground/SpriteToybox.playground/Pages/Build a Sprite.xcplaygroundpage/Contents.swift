//: [Previous](@previous)
import Cocoa
import SpriteKit
import XCPlayground

//: # Build a View!
//:
//: Create an SKView
let skview = SKView(frame:CGRectMake(0, 0, 300, 240))
let center = CGPointMake(150, 120)

//: Present an SKScene
let skscene = SKScene(size:skview.frame.size)
skview.presentScene(skscene)
XCPShowView("View", view: skview)

//: Build a Sprite Node. You choose the color.
var sprite = SKShapeNode(circleOfRadius: 40)
sprite.lineWidth = 8.0
sprite.fillColor = SpriteColor
sprite.position = center
skscene.addChild(sprite)

//: Use the toybox slider to adjust the color
extension Delegate : ValueResponder {
    public func valueDidUpdate(identity: String, _ value: Double) {
        SpriteColor = NSColor(hue:CGFloat(value), saturation: 0.85, brightness:1.0, alpha:0.5)
        sprite.fillColor = SpriteColor
        SetData("hue", "\(value)")
    }
}
manager.addValueResponder(delegate)
//: [Next](@next)
