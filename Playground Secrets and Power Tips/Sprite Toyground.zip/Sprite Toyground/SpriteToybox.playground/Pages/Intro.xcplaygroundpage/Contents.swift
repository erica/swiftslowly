import Foundation
import XCPlayground

//: # Toybox
//:
//: Interactive SpriteKit elements
//:
//: ![Let's play](./windmills.jpg)
//:
//: [Get started!](@next)
