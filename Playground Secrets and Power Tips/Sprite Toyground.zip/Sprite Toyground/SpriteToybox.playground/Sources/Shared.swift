import Foundation
import Cocoa
import XCPlayground

public var SpriteColor = NSColor(red:0.5723, green:0.9748, blue:0.5418, alpha:1.0000)

public func SetData(key: String, _ value: String) {
    let path = XCPSharedDataDirectoryPath.stringByAppendingPathComponent("ToyboxDict.plist")
    var dict : [String : String] = NSDictionary(contentsOfFile: path) as? [String : String] ?? [String : String]()
    dict[key] = value
    (dict as NSDictionary).writeToFile(path, atomically: true)
}

public func GetData(key: String) -> String? {
    let path = XCPSharedDataDirectoryPath.stringByAppendingPathComponent("ToyboxDict.plist")
    var dict : [String : String] = NSDictionary(contentsOfFile: path) as? [String : String] ?? [String : String]()
    return dict[key]
}