import Cocoa

// MARK: Interaction Protocols

public protocol TriggerResponder {
    func itemDidTrigger(identity: String)
}

public protocol ValueResponder {
    func valueDidUpdate(identity: String, _ value: Double)
}

public protocol StringResponder {
    func stringDidUpdate(identity: String, _ value: String)
}

public protocol RadioResponder {
    func matrixDidUpdate(identity: String, _ row: Int, _ column: Int)
}

// TargetAction Manager

public class TargetActionManager {
    var observer : AnyObject? = nil
    internal var triggerResponders = [TriggerResponder]()
    internal var valueResponders = [ValueResponder]()
    internal var stringResponders = [StringResponder]()
    internal var radioResponders = [RadioResponder]()
    
    public func addTriggerResponder(r : TriggerResponder) {
        triggerResponders.append(r)
    }
    
    public func addValueResponder(r : ValueResponder) {
        valueResponders.append(r)
    }
    
    public func addStringResponder(r : StringResponder) {
        stringResponders.append(r)
    }
    
    public func addRadioResponder(r : RadioResponder) {
        radioResponders.append(r)
    }
    
    internal let ToyboxNotification = "com.sadun.ToyboxNotification"
    internal let kIdentity = "kIdentity"
    internal let kTrigger = "kTrigger"
    internal let kValue = "kValue"
    internal let kString = "kString"
    internal let kRadio = "kRadio"
    internal let kRadioRow = "kRadioRow"
    internal let kRadioColumn = "kRadioColumn"
    
    internal func startListening() {
        let center = NSDistributedNotificationCenter.defaultCenter()
        observer = center.addObserverForName(ToyboxNotification,
            object: nil,
            queue: NSOperationQueue.mainQueue()) {
                (note: NSNotification!) -> Void in
               
                let dict : [NSString : AnyObject] = note.userInfo as! [NSString : AnyObject]
                guard let identity = dict[self.kIdentity] as? String else {return}
                guard let command = note.object as? NSString else {return}
                // print(identity); print(command); print(note)
                
                switch command {
                case self.kTrigger:
                    for triggerResponder in self.triggerResponders {
                        triggerResponder.itemDidTrigger(identity)
                    }
                case self.kValue:
                    guard let value = dict[self.kValue] as? Double else {return}
                    for valueResponder in self.valueResponders {
                        valueResponder.valueDidUpdate(identity, value)
                    }
                case self.kString:
                    guard let value = dict[self.kString] as? String else {return}
                    for stringResponder in self.stringResponders {
                        stringResponder.stringDidUpdate(identity, value)
                    }
                case self.kRadio:
                    guard let row = dict[self.kRadioRow] as? Int else {return}
                    guard let col = dict[self.kRadioColumn] as? Int else {return}
                    for radioResponder in self.radioResponders {
                        radioResponder.matrixDidUpdate(identity, row, col)
                    }
                default: break
                }
        }
    }
    
    public init() {
        startListening()
    }
    
    deinit {
        let center = NSDistributedNotificationCenter.defaultCenter()
        if let observer = observer {center.removeObserver(observer)}
    }
}

import XCPlayground

public class Delegate {}
func EstablishManagerWithDelegate(theDelegate : Delegate) -> TargetActionManager {
    let manager = TargetActionManager()
    XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
//    print("Manager is Ready!")
    return manager
}
public let delegate = Delegate()
public let manager = EstablishManagerWithDelegate(delegate)
