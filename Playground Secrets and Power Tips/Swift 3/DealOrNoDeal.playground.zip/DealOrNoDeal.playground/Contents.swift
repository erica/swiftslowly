import UIKit
import PlaygroundSupport

// Set up View Controller
let vc: UIViewController = {
    $0.view.backgroundColor = .white
    PlaygroundState.liveView = $0
    return $0
}(UIViewController())

let button: UIButton = {
    $0.autoLayoutEnabled = true
    $0.constrain(size: CGSize(width: 240, height: 120))
    $0.setTitle("Push Me", for: .normal)
    $0.titleLabel?.font = UIFont.boldSystemFont(ofSize: 32)
    vc.place($0, "cc")
    return $0
}(UIButton(type: .system))

let label: UILabel = {
    $0.autoLayoutEnabled = true
    $0.constrain(size: CGSize(width: 200, height: 30))
    $0.text = "What will you win?"
    $0.textAlignment = .center
    vc.place($0, "cc", offsetv: -30)
    return $0
}(UILabel())

vc.view.addSubview(label)

extension UIViewController {
    func go() {
        let roll = arc4random_uniform(100)
        switch roll {
        case 0 ..< 60: label.text = "You won a penny"
        case 60 ..< 80: label.text = "You won two pennies"
        case 80 ..< 90: label.text = "You won a nickel"
        case 90 ..< 97: label.text = "You won a dime"
        default: label.text = "You won a quarter"
        }
    }
}

button.addTarget(vc, action: #selector(UIViewController.go), for: .touchUpInside)
