//: # Sample OS X App
//: Uncomment out the following line of code to get started
import UIKit
import PlaygroundSupport

// PlaygroundPage.current.needsIndefiniteExecution = true



//: This call creates an `UIView` instance and sets it
//: as the live view
// Create and present a UIView instance
let view = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 200))
PlaygroundPage.current.liveView = view

/*:
     for i in 1...10 {
         print(i)
     }
 
 */
