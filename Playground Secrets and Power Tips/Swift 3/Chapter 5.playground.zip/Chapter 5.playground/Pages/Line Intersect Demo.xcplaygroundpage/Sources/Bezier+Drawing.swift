/*
 
 ericasadun.com
 Bezier Drawing Utility
 
 */

import UIKit

public func PushDraw(block: ()->()) {
    let context : CGContext! = UIGraphicsGetCurrentContext()
    if (context == nil) {return}
    context.saveGState()
    block()
    context.restoreGState()
}

public func DrawImage(size : CGSize, block : () -> ()) -> UIImage {
    UIGraphicsBeginImageContextWithOptions(size, false, 0)
    block()
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return image!
}

public var BezierStrokeColorKey = "BezierStrokeColorKey"
public var BezierFillColorKey = "BezierFillColorKey"

public extension UIBezierPath {
    
    public var strokeColor : UIColor? {
        get {return objc_getAssociatedObject(self, &BezierStrokeColorKey) as? UIColor}
        set {objc_setAssociatedObject(self, &BezierStrokeColorKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)}
    }
    
    public var fillColor : UIColor? {
        get {return objc_getAssociatedObject(self, &BezierFillColorKey) as? UIColor}
        set {objc_setAssociatedObject(self, &BezierFillColorKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)}
    }
    
    public func stroke(width: CGFloat) {
        let copy = self.copy() as! UIBezierPath; copy.lineWidth = width
        let color = (strokeColor != nil) ? (strokeColor!) : UIColor.black
        PushDraw{color.set(); copy.stroke()}
    }
    
    public func strokeWithColor(color : UIColor) {
        PushDraw{color.set(); self.stroke()}
    }
    
    public func strokeWithColor(color : UIColor, width : CGFloat) {
        let copy = self.copy() as! UIBezierPath; copy.lineWidth = width
        PushDraw{color.set(); copy.stroke()}
    }
    
    public func fill(color : UIColor) {PushDraw {color.set(); self.fill()}}
    public func performStroke() {stroke(width: self.lineWidth)}
    public func performFill() {let color : UIColor! = (fillColor != nil) ? fillColor : UIColor.gray; fill(color: color)}
    public func performDraw() {performFill(); performStroke()}
}
