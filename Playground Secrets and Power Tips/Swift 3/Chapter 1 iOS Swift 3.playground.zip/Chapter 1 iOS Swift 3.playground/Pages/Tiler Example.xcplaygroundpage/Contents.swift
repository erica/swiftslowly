import UIKit
import PlaygroundSupport

open class ImageTiler : NSObject {
    open var rootImage : UIImage? = nil
    
    open var hcount : Int = 1 {didSet {if hcount < 1 { hcount = 1 }}}
    open var vcount : Int = 1 {didSet {if vcount < 1 { vcount = 1 }}}
    
    public convenience init(_ image : UIImage, _ hcount : Int, _ vcount : Int) {
        self.init()
        rootImage = image
        (self.hcount, self.vcount) = (hcount, vcount)
    }
    open func tile(_ h: Int, _ v : Int) -> UIImage? {
        if let rootImage = rootImage {
            let width = rootImage.size.width / CGFloat(hcount)
            let height = rootImage.size.height / CGFloat(vcount)
            
            UIGraphicsBeginImageContextWithOptions(CGSize(width: width, height: height), false, 0.0)
            let context = UIGraphicsGetCurrentContext()
            let dx = width * CGFloat(h); let dy = height * CGFloat(v)
            context!.translateBy(x: -dx, y: -dy)
            rootImage.draw(at: .zero)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return image
        }
        return nil
    }
}

let tiler = ImageTiler(UIImage(named:"groddle")!, 15, 1)
let animView = UIImageView(frame:CGRect(x: 0, y: 0, width: 78, height: 119))
animView.contentMode = .scaleAspectFit
animView.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.961, alpha: 1)
animView.animationImages = (0...10).map{tiler.tile($0, 0)!}
animView.animationDuration = 0.5
animView.animationRepeatCount = 0
animView.startAnimating()

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = animView

