import UIKit
import PlaygroundSupport
PlaygroundPage.current.liveView = backdrop
PlaygroundPage.current.needsIndefiniteExecution = true

// Added but otherwise unconstrained other than default size
backdrop.addSubviews(redview, purpleview, blueview)

// Put red in the middle
redview.centerInSuperview(priority: 500)

// Competing priorities
redview.constrain(size: CGSize(width: 200, height: 90), priority: 700)
redview.constrain(size: CGSize(width: 200, height: 90), priority: 700)

// Top-to-bottom line
View.constrain("V:[view1]-[view2]", blueview, redview, priority: 500)

// alignViews(blueview, redview, attribute: .centerY, priority: 500)
View.alignViews(blueview, redview, attribute: .centerX, priority: 500)

backdrop.layer.borderWidth = 2
backdrop.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.961, alpha: 1.0)
