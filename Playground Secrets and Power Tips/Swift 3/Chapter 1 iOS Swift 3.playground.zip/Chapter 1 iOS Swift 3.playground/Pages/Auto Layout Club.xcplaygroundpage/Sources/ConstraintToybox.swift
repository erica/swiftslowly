import UIKit

// For playing on
public let backdrop = UIView(frame: CGRect(x: 0, y: 0, width: 480, height: 320))

// Make presentable
public func StylizedView(_ color : UIColor) -> UIView {
    let view: UIView = {
        $0.translatesAutoresizingMaskIntoConstraints = false
        $0.layer.cornerRadius = 8
        $0.layer.borderColor = UIColor.black.cgColor
        $0.layer.borderWidth = 2
        $0.backgroundColor = color
        $0.constrain(width: 80, height: 80, priority: 251)
        $0.layoutIfNeeded()
        return $0
    }(UIView())
    return view
}

public let redview = StylizedView(.red)
public let blueview = StylizedView(.blue)
public let greenview = StylizedView(.green)
public let cyanview = StylizedView(.cyan)
public let yellowview = StylizedView(.yellow)
public let magentaview = StylizedView(.magenta)
public let purpleview = StylizedView(.purple)
public let orangeview = StylizedView(.orange)
public let brownview = StylizedView(.brown)
