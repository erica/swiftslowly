import UIKit

// For playing on
public let backdrop = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))

// Make presentable
public func StylizedView(_ color : UIColor) -> UIView {
    let view = UIView()
    view.translatesAutoresizingMaskIntoConstraints = false
    view.layer.cornerRadius = 8
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.borderWidth = 2
    view.backgroundColor = color
    view.constrainView(size: CGSize(width: 80, height: 80), priority: 251)
    view.layoutIfNeeded()
    return view
}


public let redview = StylizedView(.red)
public let blueview = StylizedView(.blue)
public let greenview = StylizedView(.green)
public let cyanview = StylizedView(.cyan)
public let yellowview = StylizedView(.yellow)
public let magentaview = StylizedView(.magenta)
public let purpleview = StylizedView(.purple)
public let orangeview = StylizedView(.orange)
public let brownview = StylizedView(.brown)
