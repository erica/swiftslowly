/*
 
 ericasadun.com
 Math Types
 
 */

import Foundation
import QuartzCore

// MARK: Conversion

public protocol FloatConvertible {
    var DoubleValue: Double { get }
    var FloatValue: Float { get }
    var IntValue: Int { get }
    var CGFloatValue: CGFloat { get }
}

extension CGFloat: FloatConvertible {}
extension Float: FloatConvertible {}
extension Double: FloatConvertible {}
extension Int: FloatConvertible {}

public extension CGFloat {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(self.DoubleValue)}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
}

public extension Double {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(self)}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
}

public extension Float {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(Double(self))}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
}

public extension Int {
    public var DoubleValue : Double {return Double(self)}
    public var FloatValue : Float {return Float(self)}
    public var IntValue : Int {return lrint(Double(self))}
    public var CGFloatValue : CGFloat {return CGFloat(self)}
    public var BoolValue : Bool {return self != 0}
}

