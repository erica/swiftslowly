import Foundation

var searchString = "Test Phrase"

func bye() -> Never { print("Could not complete the operation"); exit(-1) }

// Establish Query
guard let queryString = "client=firefox&q=\(searchString)".addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) else { bye() }
let requestString = "http://suggestqueries.google.com/complete/search?\(queryString)"
guard let url = URL(string: requestString) else { bye() }

// Fetch data
let data = try Data(contentsOf: url)
if
    let json = try JSONSerialization
    .jsonObject(with: data, options: []) as? NSArray,
    let items = json[1] as? NSArray {
    for each in items {
        each
    }
}

