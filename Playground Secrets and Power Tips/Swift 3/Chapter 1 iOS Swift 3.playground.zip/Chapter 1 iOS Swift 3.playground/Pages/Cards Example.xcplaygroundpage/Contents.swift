import Foundation
import UIKit

public enum Suit: Int, CustomStringConvertible {
    case clubs = 1, diamonds, hearts, spades
    public var description: String {
        return ["♣️", "♦️", "❤️", "♠️"][rawValue - 1]
    }
    public var nativeColor: UIColor {
        switch self {
        case .clubs, .spades: return .black
        default: return .red
        }
    }
}

public enum Rank: Int, CustomStringConvertible {
    case ace = 1, two, three, four, five, six, seven, eight, nine, ten, jack, queen, king
    public var description: String {
        return ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"][rawValue - 1]
    }
}

public struct Card: CustomPlaygroundQuickLookable {
    public let deckString = "🃑🃒🃓🃔🃕🃖🃗🃘🃙🃚🃛🃝🃞🃁🃂🃃🃄🃅🃆🃇🃈🃉🃊🃋🃍🃎🂱🂲🂳🂴🂵🂶🂷🂸🂹🂺🂻🂽🂾🂡🂢🂣🂤🂥🂦🂧🂨🂩🂪🂫🂭🂮"
    public let rawValue: Int; let suit: Suit; let rank: Rank
    
    public init(_ rawValue: Int) {
        assert(0..<52 ~= rawValue)
        self.rawValue = rawValue
        suit = Suit(rawValue: 1 + (rawValue  / 13))!
        rank = Rank(rawValue:  1 + (rawValue % 13))!
    }
    
    public init(_ rank: Rank, _ suit: Suit) {
        let r = rank.rawValue - 1
        let s = suit.rawValue - 1
        self.init(s * 13 + r)
    }
    
    public var faceString: NSAttributedString {
        let idx = deckString.characters.index(deckString.startIndex, offsetBy: rawValue)
        let idxEnd = deckString.characters.index(deckString.startIndex, offsetBy: rawValue + 1)
        let cardFace = deckString.substring(with: idx ..< idxEnd)
        return NSAttributedString(string: cardFace, attributes: [
            NSForegroundColorAttributeName: suit.nativeColor,
            NSFontAttributeName: UIFont(name:"Helvetica Neue", size: 96.0)!
        ])
    }
    
    public var customPlaygroundQuickLook : PlaygroundQuickLook {
        return PlaygroundQuickLook.attributedString(faceString)
    }
}
var king = Card(.king, .spades).faceString.mutableCopy() as! NSMutableAttributedString
king.insert(NSAttributedString(string: "\n"), at: 0)
let s = NSMutableAttributedString(string: "\n", attributes: [:])
for item in [Card(.queen, .hearts), Card(.jack, .spades), Card(.two, .clubs), Card(.five, .diamonds)] {
    s.append(item.faceString)
}
s
