/*
 
 Erica Sadun, http://ericasadun.com
 Shape initializers
 
 Samples: http://imgur.com/a/li3tf
 
 */

#if os(OSX)
    import Cocoa
#else
    import UIKit
#endif

#if os(OSX)
    public typealias Font = NSFont
    public typealias BezierPath = NSBezierPath
    public typealias Image = NSImage
    public typealias Color = NSColor
#else
    //    public typealias View = UIView
    public typealias Font = UIFont
    public typealias BezierPath = UIBezierPath
    public typealias Image = UIImage
    public typealias Color = UIColor
#endif

/// N-sided Polygon variations
extension BezierPath {
    
    /// Symmetric n-sided polygon styles
    public enum PolygonStyle {
        case flatsingle, flatdouble, curvesingle, curvedouble, flattruple, curvetruple
    }
    
    /// Establish a symmetric n-sided polygon
    public convenience init?(
        sides sideCount: Int,
        radius: CGFloat,
        style: PolygonStyle = .curvesingle,
        percentInflection: CGFloat = 0.0,
        startAngle offset: CGFloat =  0.0)
    {
        guard sideCount >= 3 else {
            print("Bezier polygon construction requires 3+ sides")
            return nil
        }
        
        func pointAt(_ theta: CGFloat, inflected: Bool = false, centered: Bool = false) -> CGPoint {
            let inflection = inflected ? percentInflection : 0.0
            let r = centered ? 0.0 : radius * (1.0 + inflection)
            return CGPoint(
                x: r * CGFloat(cos(theta)),
                y: r * CGFloat(sin(theta)))
        }
        
        let π = CGFloat(Double.pi); let 𝜏 = 2.0 * π
        let dθ = 𝜏 / CGFloat(sideCount)
        
        self.init()
        move(to: pointAt(0.0 + offset))
        
        switch (percentInflection == 0.0, style) {
        case (true, _):
            for θ in stride(from: 0.0, through: 𝜏, by: dθ) {
                addLine(to: pointAt(θ + offset))
            }
        case (false, .curvesingle):
            let cpθ = dθ / 2.0
            for θ in stride(from: 0.0, to: 𝜏, by: dθ) {
                addQuadCurve(
                    to: pointAt(θ + dθ + offset),
                    controlPoint: pointAt(θ + cpθ + offset, inflected: true))
            }
        case (false, .flatsingle):
            let cpθ = dθ / 2.0
            for θ in stride(from: 0.0, to: 𝜏, by: dθ) {
                addLine(to: pointAt(θ + cpθ + offset, inflected: true))
                addLine(to: pointAt(θ + dθ + offset))
            }
        case (false, .curvedouble):
            let (cp1θ, cp2θ) = (dθ / 3.0, 2.0 * dθ / 3.0)
            for θ in stride(from: 0.0, to: 𝜏, by: dθ) {
                addCurve(
                    to: pointAt(θ + dθ + offset),
                    controlPoint1: pointAt(θ + cp1θ + offset, inflected: true),
                    controlPoint2: pointAt(θ + cp2θ + offset, inflected: true)
                )
            }
        case (false, .flatdouble):
            let (cp1θ, cp2θ) = (dθ / 3.0, 2.0 * dθ / 3.0)
            for θ in stride(from: 0.0, to: 𝜏, by: dθ) {
                addLine(to: pointAt(θ + cp1θ + offset, inflected: true))
                addLine(to: pointAt(θ + cp2θ + offset, inflected: true))
                addLine(to: pointAt(θ + dθ + offset))
            }
            
        case (false, .flattruple):
            let (cp1θ, cp2θ) = (dθ / 3.0, 2.0 * dθ / 3.0)
            for θ in stride(from: 0.0, to: 𝜏, by: dθ) {
                addLine(to: pointAt(θ + cp1θ + offset, inflected: true))
                addLine(to: pointAt(θ + dθ / 2.0 + offset, centered: true))
                addLine(to: pointAt(θ + cp2θ + offset, inflected: true))
                addLine(to: pointAt(θ + dθ + offset))
            }
        case (false, .curvetruple):
            let (cp1θ, cp2θ) = (dθ / 3.0, 2.0 * dθ / 3.0)
            for θ in stride(from: 0.0, to: 𝜏, by: dθ) {
                addQuadCurve(
                    to: pointAt(θ + dθ / 2.0 + offset, centered:true),
                    controlPoint: pointAt(θ + cp1θ + offset, inflected: true))
                addQuadCurve(
                    to: pointAt(θ + dθ + offset),
                    controlPoint: pointAt(θ + cp2θ + offset, inflected: true))
            }
        }
        
        close()
    }
}
