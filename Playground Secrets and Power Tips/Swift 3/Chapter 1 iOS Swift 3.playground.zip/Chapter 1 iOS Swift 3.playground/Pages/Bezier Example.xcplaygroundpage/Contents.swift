import UIKit

BezierPath(sides: 8, radius: 100, style: .flatsingle, percentInflection: -1.5)
