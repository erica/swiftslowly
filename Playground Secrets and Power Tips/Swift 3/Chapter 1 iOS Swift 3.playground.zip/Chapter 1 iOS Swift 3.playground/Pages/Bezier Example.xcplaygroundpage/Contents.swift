import UIKit

BezierStarShape(inflections: 8, length: 100, percent: -1.5)
