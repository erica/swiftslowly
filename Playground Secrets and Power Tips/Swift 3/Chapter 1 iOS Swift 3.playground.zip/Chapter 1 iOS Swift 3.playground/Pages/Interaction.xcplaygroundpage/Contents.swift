import Foundation

1 + 1

let x = 59
x + 22

func isEven(_ number: Int) -> Bool {
    return (number % 2) == 0
}

isEven(x)
isEven(x + 1)
