import UIKit

// Uncomment function to see effect
//func myFunction() -> NotReal {
//    
//}

"Hello World" // no sidebar results
