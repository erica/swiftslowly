//: [Previous](@previous)
import UIKit
import PlaygroundSupport

guard let image = UIImage(named: "BlueCircles") else {
    fatalError("image not found")
}
let imageView = UIImageView(image: image)
PlaygroundPage.current.liveView = imageView

//: [Next](@next)
