import UIKit
import CoreText

func loadFont(name: String) -> Bool {
    guard let path = Bundle.main
        .path(forResource: name, ofType: "ttf") else { return false }
    let url = NSURL(fileURLWithPath: path)
    let dataProvider = CGDataProvider(url: url)
    let newFont = CGFont(dataProvider!)
    let newFontName = newFont.postScriptName
    let success = CTFontManagerRegisterGraphicsFont(newFont, nil)
    print(success ? "Loaded \(newFontName!)" :
        "Unable to load font \(name)")
    return success
}

if
    loadFont(name: "Ubuntu-B"),
    let font = UIFont(name: "Ubuntu", size: 32.0)
{
    let attributedString = NSAttributedString(
        string: "Hello World",
        attributes: [NSFontAttributeName: font]
    )
}
