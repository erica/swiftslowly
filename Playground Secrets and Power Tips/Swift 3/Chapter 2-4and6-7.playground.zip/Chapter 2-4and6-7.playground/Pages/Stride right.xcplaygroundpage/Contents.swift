
let sequence = Array(stride(from:0.0, through: 4.0, by: 0.25))
for value in sequence {
    value // linear
    value * value // square
    value * value * value // cube
}

import UIKit
let colors = stride(from: 0.0, through: 1.0, by: 0.1).map {
    UIColor(red: CGFloat($0), green:0.5, blue:1.0, alpha: 2.0)
}
