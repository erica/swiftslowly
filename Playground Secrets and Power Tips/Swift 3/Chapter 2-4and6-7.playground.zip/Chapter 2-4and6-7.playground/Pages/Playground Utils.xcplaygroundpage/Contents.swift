import Foundation

// Bridging
extension String { var ns: NSString { return self as NSString } }

// Shared file manager
fileManager

// Show some shared information
print(PlaygroundState.sharedDataURL)
print(PlaygroundState.processName)

// Folder is created on call if it does not exist
print(PlaygroundState.myDocsFolder)

// Write to custom playground folder
do {
    let path = PlaygroundState.myDocsFolder.appendingPathComponent("test.txt")
    try "Hello world!\n".write(to: PlaygroundState.myDocsFolder.appendingPathComponent("test.txt"), atomically: true, encoding: .utf8)
    print("Check ~/Documents/Shared Playground Data/\(PlaygroundState.playgroundName)/test.txt")
} catch {
    print(error)
}

print(PlaygroundState.deviceName)
print(PlaygroundState.deviceFamily)
print(PlaygroundState.runtimeVersion)
print(PlaygroundState.mainscreenScale)
print(PlaygroundState.mainscreenDimensions)