// MARK: Conditional

#if os(iOS)
print("iOS")
#elseif os(tvOS)
print("tvOS")
#elseif os(macOS) || os(OSX) // it will get there
print("OSX")
#endif

// TODO: Something


