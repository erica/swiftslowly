import Foundation
import PlaygroundSupport

// Check OS version
guard #available(OSX 10.10, *) else {
    print("Dispatch code requires macOS 10.10 or later")
    PlaygroundPage.current.finishExecution()
}

/// Dispatches a block after `secs` seconds
public func dispatch(after secs: Int, block: @escaping () -> Void) {
    let delay = Int(NSEC_PER_SEC) * secs
    let dT = DispatchTime(uptimeNanoseconds:DispatchTime.now().rawValue + UInt64(delay))
    if #available(OSX 10.10, *) {
        DispatchQueue
            .global(qos: .default)
            .asyncAfter(deadline:  dT, execute: block)
    }
}

// Establish indefinite execution
PlaygroundPage.current.needsIndefiniteExecution = true

//print("Starting")
//dispatch(after: 2) { print("Didn't get here in time") }
//print("Ending")

//print("Starting")
//dispatch(after: 2) { print("This now prints last") }
//print("Ending")

print("Starting")
dispatch(after: 2) {
    print("Finished!")
//    CFRunLoopStop(CFRunLoopGetCurrent())
    PlaygroundPage.current.finishExecution()
}
// CFRunLoopRun()
