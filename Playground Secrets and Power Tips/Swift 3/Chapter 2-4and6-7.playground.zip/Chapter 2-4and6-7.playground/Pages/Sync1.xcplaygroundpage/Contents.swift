import Foundation
import PlaygroundSupport

// Establish indefinite execution
PlaygroundPage.current.needsIndefiniteExecution = true

// Check OS version
guard #available(OSX 10.10, *) else {
    print("Dispatch code requires macOS 10.10 or later")
    PlaygroundPage.current.finishExecution()
}

print("Starting")
/// Dispatches a block after `secs` seconds
public func dispatch(after secs: Int, block: @escaping () -> Void) {
    let delay = Int(NSEC_PER_SEC) * secs
    let dT = DispatchTime(uptimeNanoseconds:DispatchTime.now().rawValue + UInt64(delay))
    if #available(OSX 10.10, *) {
        DispatchQueue
            .global(qos: .default)
            .asyncAfter(deadline:  dT, execute: block)
    }
}

dispatch(after: 2) {
    print("Finished!")
    PlaygroundPage.current.finishExecution()
}
