import Cocoa
import PlaygroundSupport

// Establish drop view
let dropView = DropView(frame: NSRect(x: 0, y: 0, width: 600, height: 200))
dropView.stringValue = "Drop Text Files"

dropView.handler = {
    // Print out each file name and image size
    for path in $0 {
        guard let string = try? String(contentsOfFile: path) else {
            print("Skipping", path); continue
        }
        print(path.ns.lastPathComponent, ":",
              string.ns.components(separatedBy: " ").count)
    }
}

// Run live
PlaygroundPage.current.liveView = dropView
PlaygroundPage.current.needsIndefiniteExecution = true
