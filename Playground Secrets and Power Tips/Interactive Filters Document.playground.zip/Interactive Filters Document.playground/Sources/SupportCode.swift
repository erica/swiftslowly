import Cocoa


public func LoadItemArray(inout itemArray : NSArray) -> NSWindow? {
    var outputValue = AutoreleasingUnsafeMutablePointer<NSArray?>(&itemArray)
    NSBundle.mainBundle().loadNibNamed("MainMenu", owner: nil, topLevelObjects: outputValue)
    // NSApplication.sharedApplication().setActivationPolicy(.Regular)
    for item in itemArray {
        if item is NSWindow {
            var window = (item as? NSWindow)!
            window.level = 7
            window.setFrameOrigin(CGPointMake(300, 300))
            return window
        }
    }
    return nil
}
