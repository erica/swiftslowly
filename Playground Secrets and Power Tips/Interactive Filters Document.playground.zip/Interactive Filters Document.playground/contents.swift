import AppKit
import XCPlayground
import Carbon
import QuartzCore

// If the playground appears dimmed, choose Editor > Execute Playground

var itemArray = NSArray()
var window = LoadItemArray(&itemArray)!
let sliderTag = 11

/*:
# CIColorMonochrome
_Remaps colors so they fall within shades of a single color_

**Step 1**: Select an opaque color input image to work with and convert it to a `CIImage` representation.
*/
let ciimage = CIImage(data: NSImage(named: "landscape600")!.TIFFRepresentation)

/*:
**Step 2**: Configure the CIColorMonochrome filter. Set the `inputImage`, `inputIntensity`, and `inputColor` properties.  This example assigns shades of grays to the input color target but you can map to any color. */
class Delegate : NSObject {
    func update(sender : NSSlider) {
        let level = CGFloat(sender.floatValue)
        let filter = CIFilter(name: "CIColorMonochrome")
        filter.setDefaults()
        filter.setValue(ciimage, forKey: "inputImage")
        filter.setValue(1, forKey: "inputIntensity")
        // Try playing with the levels here. For example, set the red or green levels to 1.0
        filter.setValue(CIColor(red: level, green: level, blue: level, alpha:1.0), forKey: "inputColor")
        filter.valueForKey("outputImage")
    }
}
/*:
**Try it out!** Use the floating Filter Control slider to tweak the applied color and view results in real time
*/

var delegate = Delegate()
if let slider = window.contentView.viewWithTag(sliderTag) as? NSSlider {
    slider.target = delegate; slider.action = "update:"
    delegate.update(slider)
}

XCPSetExecutionShouldContinueIndefinitely(continueIndefinitely: true)
