/*
 
 Erica Sadun, http://ericasadun.com
 SuperMiniPack
 
 */

import Cocoa
public typealias View = NSView

// Auto Layout
public typealias LayoutPriority = NSLayoutPriority
public let SkipConstraint = CGRect.null.origin.x

// **************************************
// MARK: View Convenience
// **************************************

// Add views and prepare for auto layout
public extension View {
    public func addSubviews(views: View...) {
        views.forEach {
            addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
    }
}

public extension View {
    
    // Return superviews
    public var superviews: [View] {
        var array: [View] = []
        var currentView = self
        repeat {
            guard let view = currentView.superview else { break }
            array.append(view); currentView = view
        } while currentView.superview != nil
        return array
    }
    
    // Return nearest common ancestor between two views
    public func nearestCommonViewAncestorWith(otherView: View) -> View? {
        if self === otherView {return self}
        let mySuperviews = superviews
        let otherSuperviews = otherView.superviews
        
        // Check for superview relationships
        if mySuperviews.contains(otherView) {return otherView}
        if otherSuperviews.contains(self) {return self}
        
        // Check for indirect ancestor
        for eachItem in mySuperviews {
            if otherSuperviews.contains(eachItem) {return eachItem}
        }
        return nil
    }
}

// **************************************
// MARK: Constraint References
// **************************************

public extension NSLayoutConstraint {
    public var firstView: View { return firstItem as! View }
    public var secondView: View? {return secondItem as? View}
    public func refersToView(theView: View) -> Bool {
        if firstView == theView { return true }
        if let secondView = secondView { return secondView == theView }
        return false
    }
}

public extension View {
    public var externalConstraintReferences: [NSLayoutConstraint] {
        var constraints: [NSLayoutConstraint] = []
        for superview in superviews {
            for constraint in superview.constraints {
                if constraint.refersToView(self) {
                    constraints.append(constraint)
                }
            }
        }
        return constraints
    }
    
    public var internalConstraintReferences: [NSLayoutConstraint] {
        var constraints: [NSLayoutConstraint] = []
        for constraint in constraints {
            if constraint.refersToView(self) {
                constraints.append(constraint)
            }
        }
        return constraints
    }
}

// **************************************
// MARK: Enabling Auto Layout
// **************************************

public extension View {
    public var autoLayoutEnabled: Bool {
        get {return !translatesAutoresizingMaskIntoConstraints}
        set {translatesAutoresizingMaskIntoConstraints = !newValue}
    }
}


// **************************************
// MARK: Format Installation
// **************************************

public func InstallLayoutFormats(
    formats: [String],
    options: NSLayoutFormatOptions,
    metrics: [String: NSNumber]?,
    bindings: [String: AnyObject],
    priority: LayoutPriority) {
    let constraints = formats.flatMap ({
        NSLayoutConstraint.constraintsWithVisualFormat(
            $0,
            options: options,
            metrics: metrics,
            views: bindings)
    })
    constraints.forEach{$0.priority = priority}
    NSLayoutConstraint.activateConstraints(constraints)
}

// **************************************
// MARK: Sizing
// **************************************

// Constraining Sizes
public func SizeView(view: View, size: CGSize, priority: LayoutPriority) {
    let metrics  = ["width": size.width, "height": size.height]
    let bindings = ["view": view]
    var formats: [String] = []
    if size.width != SkipConstraint { formats += ["H:[view(==width)]"] }
    if size.height != SkipConstraint { formats += ["V:[view(==height)]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainMinimumViewSize(view: View, size: CGSize, priority: LayoutPriority) {
    let metrics = ["width": size.width, "height": size.height]
    let bindings = ["view": view]
    var formats: [String] = []
    if size.width != SkipConstraint { formats += ["H:[view(>=width)]"] }
    if size.height != SkipConstraint { formats += ["V:[view(>=height)]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainMaximumViewSize(view: View, size: CGSize, priority: LayoutPriority) {
    let metrics = ["width": size.width, "height": size.height]
    let bindings = ["view": view]
    var formats: [String] = []
    if size.width != SkipConstraint { formats += ["H:[view(<=width)]"] }
    if size.height != SkipConstraint { formats += ["V:[view(<=height)]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

// **************************************
// MARK: Positioning
// **************************************

// Constraining Positions
public func PositionView(view: View, point: CGPoint, priority: LayoutPriority) {
    if view.superview == nil {return}
    let metrics = ["hLoc": point.x, "vLoc": point.y]
    let bindings = ["view": view]
    var formats: [String] = []
    if point.x != SkipConstraint { formats += ["H:|-hLoc-[view]"] }
    if point.y != SkipConstraint { formats += ["V:|-vLoc-[view]"] }
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainViewToSuperview(view: View, inset: Float, priority: LayoutPriority) {
    if view.superview == nil {return}
    let formats = [
        "H:|->=inset-[view]",
        "H:[view]->=inset-|",
        "V:|->=inset-[view]",
        "V:[view]->=inset-|"]
    InstallLayoutFormats(formats, options: [], metrics: ["inset": inset], bindings: ["view": view], priority: priority)
}

// **************************************
// MARK: Stretching
// **************************************

// Stretching to Superview
public func StretchViewHorizontallyToSuperview(view: View, inset: CGFloat, priority: LayoutPriority) {
    if view.superview == nil {return}
    let metrics = ["inset": inset]
    let bindings = ["view": view]
    let formats = ["H:|-inset-[view]-inset-|"]
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func StretchViewVerticallyToSuperview(view: View, inset: CGFloat, priority: LayoutPriority) {
    if view.superview == nil {return}
    let metrics = ["inset": inset]
    let bindings = ["view": view]
    let formats = ["V:|-inset-[view]-inset-|"]
    InstallLayoutFormats(formats, options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func StretchViewToSuperview(view: View, inset: CGSize, priority: LayoutPriority) {
    if view.superview == nil {return}
    if inset.width != SkipConstraint {
        StretchViewHorizontallyToSuperview(view, inset: inset.width, priority: priority)
    }
    if inset.height != SkipConstraint {
        StretchViewVerticallyToSuperview(view, inset: inset.height, priority: priority)
    }
}

// **************************************
// MARK: Alignment
// **************************************

public func AlignViewInSuperview(view: View, attribute: NSLayoutAttribute, inset: CGFloat, priority: LayoutPriority) {
    if view.superview == nil {return}
    var actualInset: CGFloat
    switch attribute {
    case .Left, .Leading, .Top:
        actualInset = -inset
    default:
        actualInset = inset
    }
    let superview = view.superview!
    let constraint = NSLayoutConstraint(item: superview, attribute: attribute, relatedBy: .Equal, toItem: view, attribute: attribute, multiplier: 1.0, constant: actualInset)
    constraint.priority = priority
    constraint.active = true
}

public func AlignViews(priority: LayoutPriority, view1: View, view2: View, attribute: NSLayoutAttribute) {
    let constraint: NSLayoutConstraint = NSLayoutConstraint(item: view1, attribute: attribute, relatedBy: .Equal, toItem: view2, attribute: attribute, multiplier: 1, constant: 0)
    constraint.priority = priority
    constraint.active = true
}

// View to View Layout
public func CenterViewInSuperview(view: View, horizontal: Bool, vertical: Bool, priority: LayoutPriority) {
    if view.superview == nil {return}
    if horizontal {AlignViews(priority, view1: view, view2: view.superview!, attribute: .CenterX)}
    if vertical {AlignViews(priority, view1: view, view2: view.superview!, attribute: .CenterY)}
}

/// Constrain several views at once. Views are named view1, view2, view3...
public func ConstrainViews(priority: LayoutPriority, format: String, metrics: [String: NSNumber], views: [View]) {
    
    // At least one view
    if views.isEmpty {return}
    
    // Install view names to bindings
    var bindings: [String: View] = [: ]
    bindings["view"] = views.first
    for (index, view) in views.enumerate() {
        bindings["view\(index+1)"] = view
        view.translatesAutoresizingMaskIntoConstraints = false
    }
    
    // Generate and install constraints with priority
    InstallLayoutFormats([format], options: [], metrics: metrics, bindings: bindings, priority: priority)
}

public func ConstrainViews(priority: LayoutPriority, format: String, views: View...) {
    ConstrainViews(priority, format: format, metrics: [String: NSNumber](), views: views)
}

public func ConstrainView(priority: LayoutPriority, format: String, metrics: [String: NSNumber], view: View) {
    ConstrainViews(priority, format: format, metrics: metrics, views: [view])
}

public func ConstrainView(priority: LayoutPriority, format: String, view: View) {
    ConstrainView(priority, format: format, metrics: [String: NSNumber](), view: view)
}

// **************************************
// MARK: Hug / Resist
// **************************************

public extension View {
    public var horizontalContentHuggingPriority: LayoutPriority {
        get {return contentHuggingPriorityForOrientation(.Horizontal)}
        set {setContentHuggingPriority(newValue, forOrientation: .Horizontal)}
    }
    
    public var verticalContentHuggingPriority: LayoutPriority {
        get {return contentHuggingPriorityForOrientation(.Vertical)}
        set {setContentHuggingPriority(newValue, forOrientation: .Vertical)}
    }
    
    public var contentHuggingPriority: LayoutPriority {
        get {
            Swift.print("This priority is write-only"); return 250 // meaningless
        }
        set {
            setContentHuggingPriority(newValue, forOrientation: .Horizontal)
            setContentHuggingPriority(newValue, forOrientation: .Vertical)
        }
    }
    public var horizontalContentCompressionResistancePriority: LayoutPriority {
        get {return contentCompressionResistancePriorityForOrientation(.Horizontal)}
        set {setContentCompressionResistancePriority(newValue, forOrientation: .Horizontal)}
    }
    public var verticalContentCompressionResistancePriority: LayoutPriority {
        get {return contentCompressionResistancePriorityForOrientation(.Vertical)}
        set {setContentCompressionResistancePriority(newValue, forOrientation: .Vertical)}
    }
    public var contentCompressionResistancePriority: LayoutPriority {
        get {
            Swift.print("This priority is write-only"); return 750 // meaningless
        }
        set {
            setContentCompressionResistancePriority(newValue, forOrientation: .Horizontal)
            setContentCompressionResistancePriority(newValue, forOrientation: .Vertical)
        }
    }
}

// --------------------------------------------------
// MARK: Placement utility
// --------------------------------------------------

public func PlaceViewInSuperview(view: View, position: String, inseth: CGFloat, insetv: CGFloat, priority: LayoutPriority) {
    if position.characters.count != 2 {return}
    if view.superview == nil {return}
    
    view.autoLayoutEnabled = true
    
    let verticalPosition = position.substringToIndex(position.startIndex.successor())
    let horizontalPosition = position.substringFromIndex(position.startIndex.successor())
    
    switch verticalPosition as String {
    case "t":
        AlignViewInSuperview(view, attribute: .Top, inset: insetv, priority: priority)
    case "c":
        AlignViewInSuperview(view, attribute: .CenterY, inset: insetv, priority: priority)
    case "b":
        AlignViewInSuperview(view, attribute: .Bottom, inset: insetv, priority: priority)
    case "x":
        StretchViewVerticallyToSuperview(view, inset: insetv, priority: priority)
    default: break
    }
    
    switch horizontalPosition as String {
    case "l":
        AlignViewInSuperview(view, attribute: .Leading, inset: inseth, priority: priority)
    case "c":
        AlignViewInSuperview(view, attribute: .CenterX, inset: inseth, priority: priority)
    case "r":
        AlignViewInSuperview(view, attribute: .Trailing, inset: inseth, priority: priority)
    case "x":
        StretchViewHorizontallyToSuperview(view, inset: inseth, priority: priority)
    default: break
    }
}

// **************************************
// MARK: Inspection
// **************************************

public var ViewNameKey = "ViewNameKey"
public extension NSObject {
    public var visibleClassName: String {
        return "\(self.dynamicType)"
    }
    public var addressString: String {
        get {return NSString(format: "%p", self) as String}
    }
    public var debugName: String {
        return visibleClassName + ":" + addressString
    }
}

public extension View {
    public var viewName: String? {
        get {return objc_getAssociatedObject(self, &ViewNameKey) as? String}
        set {objc_setAssociatedObject(self, &ViewNameKey, newValue, .OBJC_ASSOCIATION_RETAIN)}
    }
    public var debugViewName: String {
        get {
            if visibleClassName.hasPrefix("_UI") {return visibleClassName.substringFromIndex(visibleClassName.startIndex.advancedBy(3))}
            return visibleClassName + ":" + (viewName ?? addressString)}
    }
}

public extension NSLayoutConstraint {
    public var descriptionWithViewNames: String {
        var string: NSString = description
        
        string = string.stringByReplacingOccurrencesOfString(debugName + " ", withString: "")
        
        if let viewName = firstView.viewName {
            string = string.stringByReplacingOccurrencesOfString(firstView.addressString, withString: "\"" + viewName + "\"")
        }
        
        if firstView.visibleClassName.hasPrefix("_UI") {
            let visible = firstView.visibleClassName.substringFromIndex(visibleClassName.startIndex.advancedBy(3))
            string = string.stringByReplacingOccurrencesOfString(firstView.debugName, withString: visible)
        }
        
        if let secondView = secondView {
            if let viewName = secondView.viewName {
                string = string.stringByReplacingOccurrencesOfString(secondView.addressString, withString: "\"" + viewName + "\"")
            }
            
            if secondView.visibleClassName.hasPrefix("_UI") {
                let visible = secondView.visibleClassName.substringFromIndex(visibleClassName.startIndex.advancedBy(3))
                string = string.stringByReplacingOccurrencesOfString(secondView.debugName, withString: visible)
            }
        }
        
        // return visibleClassName + ": " + (string as String)
        return string as String
    }
}

public func AddConstraint(request: String, view1: View, view2: View, m: CGFloat, c: CGFloat, priority: LayoutPriority) {
    var components: [String] = []
    for separator in [".", " "] {
        components = request.componentsSeparatedByString(separator)
        if components.count == 3 {break}
    }
    
    if components.count != 3 {
        for separator in ["<=", "==", ">=", "<", "=", ">"] {
            components = request.componentsSeparatedByString(separator)
            if components.count == 2 {
                components = [components[0], separator, components[1]]
                break
            }
        }
    }
    
    if components.count != 3 {
        print("Add constraint format error: "+request)
        return
    }
    
    let firstAttributeString = components[0].lowercaseString
    let secondAttributeString = components[2].lowercaseString
    let relationString = components[1].substringToIndex(components[1].startIndex.advancedBy(1))
    
    let attributes: [String: NSLayoutAttribute] = [
        "l": .Left, "r": .Right, "t": .Top, "b": .Bottom,
        "cx": .CenterX, "cy": .CenterY,"w": .Width,"h": .Height,
        "left": .Left, "right": .Right, "top": .Top, "bottom": .Bottom,
        "leading": .Leading, "trailing": .Trailing, "width": .Width, "height": .Height,
        "centerx": .CenterX, "centery": .CenterY,
        "baseline": .Baseline, "firstbaseline": .FirstBaseline,
        "notanattribute": .NotAnAttribute, "_": .NotAnAttribute,
        "_naa_": .NotAnAttribute, "skip": .NotAnAttribute,
        ]
    
    let relations: [String: NSLayoutRelation] = [
        "<": .LessThanOrEqual, "=": .Equal, ">": .GreaterThanOrEqual]
    
    let firstAttribute = attributes[firstAttributeString] ?? .NotAnAttribute
    let secondAttribute = attributes[secondAttributeString] ?? .NotAnAttribute
    let relation = relations[relationString] ?? .Equal
    
    let constraint = NSLayoutConstraint(item: view1, attribute: firstAttribute, relatedBy: relation, toItem: view2, attribute: secondAttribute, multiplier: m, constant: c)
    
    constraint.priority = priority
    constraint.active = true
}

public extension View {
    public func dumpViewsAtIndent(indent: Int) {
        
        if visibleClassName.hasPrefix("_UI") {return}
        
        // indent and print view
        let indentString = String(count: indent * 4, repeatedValue: Character("-"))
        let spaceString = String(count: indent * 4, repeatedValue: Character(" "))
        
        Swift.print(indentString, terminator: "")
        
        
        Swift.print("[\(debugViewName) \(frame)", terminator: "")
        if tag != 0 {Swift.print(" tag: \(tag)", terminator: "")}
        
        //        var showExtras = false
        //        if showExtras {
        //            // Hugging and resistance
        //            Swift.print(" Hug: (\(horizontalContentHuggingPriority), \(verticalContentHuggingPriority))")
        //            Swift.print(" Res: (\(horizontalContentCompressionResistancePriority), \(verticalContentCompressionResistancePriority))")
        //        }
        
        // Count and references
        if constraints.count > 0 {Swift.print(" constraints: \(constraints.count)", terminator: "")}
        let references = internalConstraintReferences + externalConstraintReferences
        if references.count > 0 {Swift.print(" references: \(references.count)", terminator: "")}
        
        Swift.print("]")
        
        // Enumerate the constraints
        for (index, constraint) in constraints.enumerate() {
            Swift.print(spaceString, terminator: "")
            Swift.print("    \(index + 1). \(constraint.descriptionWithViewNames)")
        }
        
        // Recurse
        for subview in subviews {
            subview.dumpViewsAtIndent(indent + 1)
        }
    }
    
    public func dumpViews() {
        dumpViewsAtIndent(0)
    }
}
