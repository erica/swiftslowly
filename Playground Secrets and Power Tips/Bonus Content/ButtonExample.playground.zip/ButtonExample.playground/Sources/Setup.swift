import Cocoa
import XCPlayground

public class PGView: NSView {
    public static func newView() -> PGView {
        return {
            $0.frame = NSMakeRect(0, 0, 400, 300)
            $0.wantsLayer = true
            $0.layer?.backgroundColor = NSColor.whiteColor().CGColor
            return $0
            }(PGView())
    }
}

public var view = NSView()

public func SetupPlayground() {
    view = PGView.newView()
    XCPlaygroundPage.currentPage.liveView = view
    XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
}