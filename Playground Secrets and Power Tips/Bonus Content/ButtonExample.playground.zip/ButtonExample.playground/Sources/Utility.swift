import Cocoa

public func solicitText(prompt : String, completion:(String)->()) {
    let alert = NSAlert(); alert.messageText = prompt
    let input = NSTextField(frame: CGRectMake(0, 0, 200, 24))
    alert.accessoryView = input
    alert.runModal()
    let string = input.stringValue
    withExtendedLifetime(string) {
        completion(string)
    }
}

