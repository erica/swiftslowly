import Cocoa
import XCPlayground

SetupPlayground()

public let textfield: NSTextField = {
    $0.stringValue = ""; $0.editable = false
    $0.alignment = .Center; $0.bezeled = false
    $0.font = NSFont(name: "Palatino", size: 24.0)
    view.addSubviews($0)
    SizeView($0, size: CGSizeMake(SkipConstraint, 30), priority: 1000)
    StretchViewHorizontallyToSuperview($0, inset: 20, priority: 1000)
    PlaceViewInSuperview($0, position: "tc", inseth: 0, insetv: 40, priority: 1000)
    return $0
}(NSTextField())

public class Delegate: NSObject {
    func respond() {
        solicitText("What is your name?", completion: { (response: String) -> () in
            switch response.isEmpty {
            case true: textfield.stringValue = "Hi, anonymous person!"
            case false: textfield.stringValue = "Hello \(response)!"
            }
        })
    }
}
let delegate = Delegate()

public let button: NSButton = {
    $0.title = "Push me"
    $0.font = NSFont(name: "Palatino", size: 14.0)
    view.addSubviews($0)
    PlaceViewInSuperview($0, position: "cc", inseth: 0, insetv: 0, priority: 1000)
    return $0
}(NSButton())

button.target = delegate
button.action = #selector(Delegate.respond)
