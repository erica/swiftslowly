import Cocoa

// Support Foundation calls on String
public extension String { public var ns: NSString {return self as NSString} }

/// Custom Labeled Playground-Based Drag-and-Drop window
public class DropView: NSTextField {
    
    // Default action handler
    public var handler: ([String]) -> Void = { paths in Swift.print(paths) }

    // Drag and drop notification
    public override func draggingEntered(sender: NSDraggingInfo) -> NSDragOperation { return NSDragOperation.Copy }
    public override func draggingUpdated(sender: NSDraggingInfo) -> NSDragOperation { return NSDragOperation.Copy }
    public override func performDragOperation(sender: NSDraggingInfo) -> Bool {
        let pboard = sender.draggingPasteboard()
        guard let paths = pboard.propertyListForType(NSFilenamesPboardType) as? [String] else { return false }
        handler(paths)
        return true
    }
    
    public required init?(coder: NSCoder) { super.init(coder: coder) }
    public override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        
        // Presentation
        stringValue = "Drop Here"; editable = false
        font = NSFont(name: "Palatino", size: 48.0); alignment = .Center
        wantsLayer = true; layer?.backgroundColor = NSColor.whiteColor().CGColor

        // Register for file name drags
        registerForDraggedTypes([NSFilenamesPboardType])
    }
}