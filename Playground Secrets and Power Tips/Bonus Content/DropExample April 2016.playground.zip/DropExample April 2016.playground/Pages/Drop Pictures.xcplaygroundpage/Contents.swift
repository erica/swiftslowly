import Cocoa
import XCPlayground

// Establish drop view
let dropView = DropView(frame: NSRect(x: 0, y: 0, width: 600, height: 200))
dropView.stringValue = "Drop Pictures"
dropView.handler = {
    // Print out each file name and image size
    $0.forEach {
        if let image = NSImage(contentsOfFile: $0) {
            Swift.print($0.ns.lastPathComponent, image.size)
        } else {
            Swift.print($0.ns.lastPathComponent, "is not an image")
        }
    }
}

// Run live
XCPlaygroundPage.currentPage.liveView = dropView
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
