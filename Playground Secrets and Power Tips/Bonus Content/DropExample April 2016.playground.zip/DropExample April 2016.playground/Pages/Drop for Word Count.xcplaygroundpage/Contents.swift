import Cocoa
import XCPlayground

// Establish drop view
let dropView = DropView(frame: NSRect(x: 0, y: 0, width: 600, height: 200))
dropView.stringValue = "Drop text files here for word counts"
dropView.handler = {
    print("Word Counts")
    for path in $0 {
        guard let string = try? String(contentsOfFile: path) else { continue }
        print(path.ns.lastPathComponent, ":",
              string.ns.componentsSeparatedByString(" ").count)
    }
}

// Run live
XCPlaygroundPage.currentPage.liveView = dropView
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
