import Cocoa
import XCPlayground

// Show compilation hint
//DisplayCompileCommand()

// Load or load and establish run loop
var loadAndRun = false; if (loadAndRun) {Launch()}

// Add playground-specific callback behavior
var n = 0
extension Delegate {
    func react(button : NSButton) {println("Click \(++n)")}
}

// Create button callback
if let button = FetchView(type: NSButton.self) {
    button.target = delegate; button.action = Selector("react:")
}

