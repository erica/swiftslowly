import UIKit

let image = UIImage(named:"landscape600")!

Sharpen(image)
Emboss(image)
Blur5(image)
Gauss5(image)
