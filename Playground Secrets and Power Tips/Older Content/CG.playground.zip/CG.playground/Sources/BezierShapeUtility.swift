import UIKit
public func BezierStarShape(inflections: Int, length : CGFloat, percent: CGFloat) -> UIBezierPath {
    
    if inflections < 3 {
        return UIBezierPath(ovalInRect: CGRectMake(0, 0, length, length))
    }
    
    let π = CGFloat(Darwin.M_PI)
    let path = UIBezierPath()
    let center = CGPointMake(length, length)
    let radius : CGFloat = length
    let rradius = radius * percent
    
    var firstPoint = true
    for i in 0...(inflections - 1) {
        let theta = π + CGFloat(i) * 2.0 * π / CGFloat(inflections)
        let dTheta = 2.0 * π / CGFloat(inflections)
        
        var p = CGPointZero
        if firstPoint {
            p.x = center.x + radius * CGFloat(cos(theta))
            p.y = center.y + radius * CGFloat(sin(theta))
            path.moveToPoint(p)
            firstPoint = false
        }
        
        let cp1x = center.x + rradius * cos(theta + dTheta / 2.0)
        let cp1y = center.y + rradius * sin(theta + dTheta / 2.0)
        let cp1 = CGPointMake(cp1x, cp1y)
        
        p.x = center.x + radius * CGFloat(cos(theta + dTheta))
        p.y = center.y + radius * CGFloat(sin(theta + dTheta))
        path.addLineToPoint(cp1)
        path.addLineToPoint(p)
    }
    path.closePath()
    return path
}
