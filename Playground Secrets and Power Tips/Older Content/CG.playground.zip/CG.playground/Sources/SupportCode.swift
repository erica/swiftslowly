import Foundation
import QuartzCore

public let random = {CGFloat(arc4random_uniform(50))}
