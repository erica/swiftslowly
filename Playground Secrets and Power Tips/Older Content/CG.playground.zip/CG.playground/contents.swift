import UIKit

/// Draw into an image
public func DrawImage(size : CGSize, block : () -> ()) -> UIImage {
    UIGraphicsBeginImageContextWithOptions(size, false, 0)
    block()
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return image
}



BezierStarShape(8, length: 100, percent: -1.5)


