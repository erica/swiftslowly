//: Playground - noun: a place where people can play

import Cocoa
import XCPlayground

public extension String {
    public var ns: NSString {return self as NSString}
}

XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
NSApplication.sharedApplication()
    .setActivationPolicy(.Regular)

NSNotificationCenter.defaultCenter()
    .addObserverForName(DroppedNotification,
        object: nil, queue: NSOperationQueue.mainQueue()) {
            note in
            guard let pasteboard =
                note.object as? NSPasteboard else {return}
            guard let paths: [String] = pasteboard
                .propertyListForType(NSFilenamesPboardType)
                as? [String] else {return}
            
            print("Word Count")
            for path in paths {
                guard let string =
                    try? String(contentsOfFile: path) else {continue}
                print(path.ns.lastPathComponent, ":", string.ns.length)
            }
}

guard let dropWindow = DropWindow(
    title: "Drop Files",
    draggedTypes: [NSFilenamesPboardType]) else {
        fatalError("Could not construct window")
}
dropWindow.makeKeyAndOrderFront(nil)
