import Cocoa

public let DroppedNotification = "DroppedNotification"
public class DropWindow : NSWindow {
    required public init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override public init(
        contentRect: NSRect,
        styleMask aStyle: Int,
        backing bufferingType: NSBackingStoreType,
        `defer` flag: Bool) {
            super.init(
                contentRect: contentRect,
                styleMask: aStyle,
                backing: bufferingType,
                `defer`: flag)
    }
    
    convenience public init?(title: String = "Drop Here",
        draggedTypes: [String] = [NSFilenamesPboardType]) {
            self.init(contentRect: CGRectMake(0, 100, 200, 200),
                styleMask: NSTitledWindowMask,
                backing: .Buffered,
                `defer`: false)
            self.registerForDraggedTypes(draggedTypes)
            self.title = title
            self.level = 7
    }
    
    public func draggingEntered(
        sender: NSDraggingInfo!) -> NSDragOperation {
            return NSDragOperation.Copy
    }
    public func draggingUpdated(
        sender: NSDraggingInfo!) -> NSDragOperation {
            return NSDragOperation.Copy
    }
    
    public func performDragOperation(sender: NSDraggingInfo!) {
        let pboard = sender.draggingPasteboard()
        let note = NSNotification(
            name: DroppedNotification, object: pboard)
        NSNotificationCenter.defaultCenter().postNotification(note)
    }
}
