import UIKit

var image = Spirograph(CGSizeMake(600, 600), 2048, -2, 130)
